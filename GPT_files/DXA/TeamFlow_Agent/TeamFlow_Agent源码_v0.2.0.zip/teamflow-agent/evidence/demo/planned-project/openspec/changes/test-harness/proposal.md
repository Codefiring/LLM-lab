# 验收测试设施
## Why
实现示例工单变更的一项独立可验收工作，降低多人并行时的交接成本。
## What Changes
- 验收测试设施，对应 R05 / AC05。
## Capabilities
### New Capabilities
- 无；仅测试设施或已定义行为的接线，设置 skip_specs: true。
### Modified Capabilities
- 无。
## Impact
写入范围：tests/ticketing/。本文件是待开发示例，不是完成证明。
