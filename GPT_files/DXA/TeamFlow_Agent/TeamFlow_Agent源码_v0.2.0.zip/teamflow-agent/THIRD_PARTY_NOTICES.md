# Third-party notices

TeamFlow source: MIT, Copyright (c) 2026 TeamFlow contributors.

OpenSpec CLI: @fission-ai/openspec 1.13.1, MIT, Copyright (c) 2024 OpenSpec Contributors.
Upstream: https://github.com/Fission-AI/OpenSpec
The upstream MIT notice is reproduced in licenses/OpenSpec-MIT.txt.
The CLI and its npm transitive dependencies are installed by the consumer using package-lock.json; node_modules is not redistributed in this source package. Each transitive dependency retains its own upstream license.

Python standard library is provided by the user's Python distribution. No third-party Python runtime dependency or model weight is bundled. Model service and model weight licenses are the operator's independent responsibility.
