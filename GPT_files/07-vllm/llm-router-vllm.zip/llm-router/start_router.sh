#!/usr/bin/env bash
set -euo pipefail

python -m uvicorn router:app \
  --host 0.0.0.0 \
  --port 9000 \
  --workers 1