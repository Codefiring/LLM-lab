"""Deterministic HTTP TEST DOUBLE. No language model or inference is used."""
from __future__ import annotations
from contextlib import contextmanager
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import json
from pathlib import Path
import threading
from .common import read_json

DEMO = Path(__file__).parent / "assets/demo"
GOOD_CODE = '''"""Small deterministic demo contract, not a complete ticketing system."""
REQUIRED_FIELDS = ("id", "title", "status", "actor_id", "tenant_id", "idempotency_key")
ERROR_INVALID_INPUT = "INVALID_INPUT"

def validate_ticket(payload):
    if not isinstance(payload, dict):
        return {"ok": False, "error": ERROR_INVALID_INPUT}
    missing = [key for key in REQUIRED_FIELDS if not isinstance(payload.get(key), str) or not payload[key].strip()]
    if missing or payload.get("status") not in ("open", "closed"):
        return {"ok": False, "error": ERROR_INVALID_INPUT, "missing": missing}
    return {"ok": True, "error": None}
'''


class FixtureResponder:
    def __init__(self, inject_errors=True):
        self.inject_errors = inject_errors
        self.counts = {}
        self.requests = []

    def __call__(self, body):
        payload = json.loads(body["messages"][-1]["content"])
        stage = payload["stage"]
        self.requests.append(body)
        self.counts[stage] = self.counts.get(stage,0)+1
        first = self.inject_errors and self.counts[stage] == 1
        if stage == "doctor":
            return {"ok":True}
        if stage == "plan":
            value = read_json(DEMO / "plan.json")
            if first:
                value["tasks"][0]["depends_on"] = [value["tasks"][0]["id"]]
            return value
        if stage.startswith("artifact-"):
            tid = payload["task"]["id"]
            root = DEMO / "changes" / tid
            result = {k:(root / (k+".md")).read_text(encoding="utf-8") for k in ("proposal","design","contracts","tasks")}
            result["specs"] = [{"capability":p.parent.name,"content":p.read_text(encoding="utf-8")}
                               for p in sorted(root.glob("specs/*/spec.md"))]
            result["skip_specs"] = not result["specs"]
            if first and tid == "foundation-contracts":
                result["contracts"] = ""
            return result
        if stage == "develop":
            code = "def validate_ticket(payload):\n    return {'ok': True, 'error': None}\n" if first else GOOD_CODE
            return {"summary":"TEST DOUBLE fixture edit, not model-generated reasoning",
                    "files":[{"path":"contracts/ticket-v1/validator.py","content":code}]}
        raise ValueError("unknown fixture stage")


@contextmanager
def serve(responder=None, statuses=()):
    responder = responder or FixtureResponder()
    captured = []
    status_queue = list(statuses)
    class Handler(BaseHTTPRequestHandler):
        def log_message(self,*args):
            pass
        def reply(self,status,value):
            raw = json.dumps(value,ensure_ascii=False).encode()
            self.send_response(status)
            self.send_header("Content-Type","application/json")
            self.send_header("Content-Length",str(len(raw)))
            self.send_header("X-TeamFlow-Test-Double","true")
            self.end_headers()
            try:
                self.wfile.write(raw)
            except (BrokenPipeError,ConnectionResetError):
                pass
        def do_GET(self):
            captured.append({"method":"GET","path":self.path,"authorization":self.headers.get("Authorization")})
            self.reply(200,{"data":[{"id":"teamflow-test-double"}]})
        def do_POST(self):
            body = json.loads(self.rfile.read(int(self.headers["Content-Length"])))
            captured.append({"method":"POST","path":self.path,"authorization":self.headers.get("Authorization"),"body":body})
            if status_queue:
                status = status_queue.pop(0)
                if status != 200:
                    self.reply(status,{"error":{"message":"injected test error"}})
                    return
            value = responder(body)
            self.reply(200,{"id":"mock-response","model":"teamflow-test-double",
                           "choices":[{"message":{"role":"assistant","content":json.dumps(value,ensure_ascii=False)},
                                       "finish_reason":"stop"}],"usage":None})
    server = ThreadingHTTPServer(("127.0.0.1",0),Handler)
    server.daemon_threads = True
    thread = threading.Thread(target=server.serve_forever,daemon=True)
    thread.start()
    try:
        yield {"base_url":f"http://127.0.0.1:{server.server_port}/v1",
               "model":"teamflow-test-double","http_retries":2,"retry_delay_seconds":0}, captured, responder
    finally:
        server.shutdown()
        server.server_close()
        thread.join(timeout=2)
