# 工单契约
## Produces
集成接线与回归的实现或验收产物。
## Consumes
ticket-api, ticket-ui, audit-events, test-harness；对应契约路径 contracts/ticket-v1/。
## Version and compatibility
ticket-v1。开发开始前应由 foundation-contracts 的真实 CI 验证并集成；此示例尚未实现契约代码。
## Mocks and verification
统一 mock 使用同一契约。验收编号 AC06；其具体测试须在试点开始前由评审者冻结。
