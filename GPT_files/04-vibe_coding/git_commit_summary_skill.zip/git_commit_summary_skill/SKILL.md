---
name: git-commit-summary-html
summary: Summarize commits in a Git repository within a specified time range and generate a visual HTML report showing implemented features, changed modules, commit timeline, authors, and file-level impact.
---

# Git Commit Summary HTML Skill

Use this skill when the user wants to analyze a code repository's commits within a specified time range and generate a visual HTML report that explains what features or changes those commits implemented.

## What this skill does

Given a local Git repository and a time window, this skill:

1. Collects commits in the selected time range.
2. Extracts commit metadata, commit messages, changed files, diff stats, and optional patch snippets.
3. Groups commits into likely feature/change categories.
4. Produces a self-contained HTML report with:
   - Executive summary
   - Commit timeline
   - Feature/change cards
   - Author contribution summary
   - File/module impact table
   - Commit detail list
   - Optional raw JSON data embedded in the page

## Inputs

Required:

- `repo_path`: local path to a Git repository
- `since`: start time, accepted by Git, for example `2026-05-01`, `2026-05-01 00:00:00`
- `until`: end time, accepted by Git, for example `2026-05-31`, `2026-05-31 23:59:59`

Optional:

- `branch`: branch or ref to analyze. Default: current branch.
- `output`: HTML output path. Default: `commit_summary.html`.
- `max_patch_chars`: max patch text captured per commit for LLM summarization. Default: `8000`.
- `include_merges`: whether to include merge commits. Default: `false`.
- `llm_summary`: whether to ask an LLM to summarize functional changes. Default: `false`.
- `openai_model`: model name used when `llm_summary=true`.

## Recommended workflow

1. Validate that `repo_path` exists and is a Git repository.
2. Run Git log for the requested date range.
3. For each commit, collect:
   - hash
   - short hash
   - author
   - author email
   - date
   - subject
   - body
   - changed file stats
   - changed modules inferred from paths
   - optional patch excerpt
4. Infer feature groups from commit messages and file paths.
5. Generate a visual HTML report.
6. Tell the user where the report was saved.

## Usage

```bash
python commit_summary_report.py \
  --repo /path/to/repo \
  --since "2026-05-01" \
  --until "2026-05-31 23:59:59" \
  --output commit_summary.html
```

With a specific branch:

```bash
python commit_summary_report.py \
  --repo /path/to/repo \
  --branch main \
  --since "2026-05-01" \
  --until "2026-05-31" \
  --output may_commit_summary.html
```

Include merge commits:

```bash
python commit_summary_report.py \
  --repo /path/to/repo \
  --since "2026-05-01" \
  --until "2026-05-31" \
  --include-merges
```

## Output interpretation

The generated report should focus on implemented functions/features, not only raw commit messages. When LLM summarization is unavailable, use rule-based grouping:

- Commit prefix: `feat`, `fix`, `refactor`, `docs`, `test`, `chore`, `perf`, `security`
- High-impact paths: `api`, `server`, `backend`, `frontend`, `ui`, `auth`, `db`, `database`, `tests`, `docs`, `security`, `mcp`, `agent`, `tools`
- Changed file clusters by top-level directories

## Safety and accuracy notes

- Do not claim a feature exists only because a commit message says so. Cross-check with changed file paths and diff stats.
- If the commit message is vague, mark the feature as inferred.
- Avoid sending proprietary source code to an external LLM unless the user explicitly permits it.
- Prefer summarizing patches locally with file names and diff stats. Only include patch content in prompts when allowed.

## Failure cases

If no commits are found, produce an HTML report that clearly states:

- selected repository
- selected time range
- selected branch/ref
- that no matching commits were found

If Git is unavailable or the path is not a Git repository, stop and return a clear error.
