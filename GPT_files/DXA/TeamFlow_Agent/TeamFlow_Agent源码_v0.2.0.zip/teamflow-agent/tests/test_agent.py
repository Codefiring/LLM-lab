import concurrent.futures
import copy
import json
import os
from pathlib import Path
import shutil
import tempfile
import threading
import time
import unittest
from unittest.mock import patch
from teamflow_agent.common import Trace, TeamFlowError, parse_object, read_json, write_json
from teamflow_agent.llm import Client
from teamflow_agent.workflow import validate_plan, validate_inputs, artifact_files, install_bundle, json_loop
from teamflow_agent.planning import schedule, conflicts
from teamflow_agent.developer import apply_files, load_checks, run_checks, develop_run
from teamflow_agent.coordinator import Coordinator
from teamflow_agent.context import collect_context
from teamflow_agent.mock_server import serve, FixtureResponder, DEMO
from teamflow_agent.demo import run_demo
from teamflow_agent.batch import run_batch
from teamflow_agent.common import git


class TempCase(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory(prefix="teamflow-test-")
        self.root = Path(self.tmp.name)
    def tearDown(self):
        self.tmp.cleanup()
    def trace(self,name="trace"):
        return Trace(self.root/name)


class PlanTests(TempCase):
    def data(self):
        return read_json(DEMO/"plan.json"),read_json(DEMO/"requirements.json"),read_json(DEMO/"members.json")
    def test_schedule_constraints(self):
        p,r,t = self.data()
        result = schedule(p,r,t)
        rows = {x["task_id"]:x for x in result["assignments"]}
        tasks = {x["id"]:x for x in p["tasks"]}
        self.assertEqual(result["team_size"],4)
        for a in rows.values():
            for d in tasks[a["task_id"]]["depends_on"]:
                self.assertGreaterEqual(a["start_hour"],rows[d]["end_hour"])
            for b in rows.values():
                if a is b:
                    continue
                if a["owner"] == b["owner"] or conflicts(tasks[a["task_id"]],tasks[b["task_id"]]):
                    self.assertFalse(a["start_hour"] < b["end_hour"] and b["start_hour"] < a["end_hour"])
    def test_cycle_rejected(self):
        p,r,t = self.data()
        p["tasks"][0]["depends_on"] = [p["tasks"][-1]["id"]]
        with self.assertRaisesRegex(ValueError,"cycle"):
            validate_plan(p,r,t)
    def test_uncovered_requirement_rejected(self):
        p,r,t = self.data()
        r["requirements"].append({"id":"R99","source":"design#R99","acceptance_tests":["AC99"]})
        with self.assertRaisesRegex(ValueError,"uncovered"):
            validate_plan(p,r,t)
    def test_unavailable_skill_rejected(self):
        p,r,t = self.data()
        p["tasks"][0]["required_skills"] = ["nonexistent"]
        with self.assertRaisesRegex(ValueError,"eligible"):
            validate_plan(p,r,t)
    def test_duplicate_requirements_rejected(self):
        p,r,t = self.data()
        r["requirements"].append(r["requirements"][0])
        with self.assertRaisesRegex(ValueError,"unique"):
            validate_inputs(r,t)
    def test_invalid_paths_and_hours(self):
        p,r,t = self.data()
        for path in ("../escape","/tmp/x","a//b","x\\y","*"):
            q = copy.deepcopy(p);q["tasks"][0]["paths_write"] = [path]
            with self.assertRaises(ValueError):
                validate_plan(q,r,t)
        p["tasks"][0]["estimate_hours"] = float("nan")
        with self.assertRaises(ValueError):
            validate_plan(p,r,t)
    def test_json_formats(self):
        fence = chr(96)*3
        self.assertEqual(parse_object('<think>private</think>\n'+fence+'json\n{"a":1}\n'+fence),{"a":1})
        with self.assertRaises(ValueError):
            parse_object("[]")
    def test_context_is_bounded(self):
        d = self.root/"design";d.mkdir()
        (d/"doc.md").write_text("\n".join("R01 body "+str(i) for i in range(5000)))
        ctx = collect_context(d,read_json(DEMO/"requirements.json"),max_chars=1500)
        self.assertTrue(ctx["context_truncated"])
        self.assertLess(len(json.dumps(ctx)),12000)
    def test_artifact_skip_and_complete_rejected(self):
        task = read_json(DEMO/"plan.json")["tasks"][0]
        responder = FixtureResponder(False)
        obj = responder({"messages":[{"content":json.dumps({"stage":"artifact-foundation-contracts","task":task})}]})
        obj["tasks"] = obj["tasks"].replace("[ ]","[x]")
        with self.assertRaisesRegex(ValueError,"unchecked"):
            artifact_files(task,obj)
        obj["tasks"] = "- [ ] 1. Verify AC01"
        obj["skip_specs"] = True;obj["specs"] = []
        with self.assertRaisesRegex(ValueError,"tooling_only"):
            artifact_files(task,obj)


class HTTPTests(TempCase):
    def test_doctor_uses_real_http_and_redacts_key(self):
        with serve() as (cfg,captured,_), patch.dict(os.environ,{"TEAMFLOW_API_KEY":"TEST-PRIVATE-KEY"}):
            tr = self.trace()
            client = Client(cfg,tr)
            self.assertTrue(client.doctor()["chat_ok"])
            self.assertEqual(captured[-1]["authorization"],"Bearer TEST-PRIVATE-KEY")
            self.assertEqual(captured[-1]["path"],"/v1/chat/completions")
            tr.save("secret.txt","TEST-PRIVATE-KEY")
            self.assertNotIn("TEST-PRIVATE-KEY","".join(p.read_text() for p in tr.root.rglob("*") if p.is_file()))
    def test_custom_path_options_and_no_auth(self):
        with serve() as (cfg,captured,_):
            cfg.update(base_url=cfg["base_url"].replace("/v1","/local/v1/"),
                       api_key_env="",json_mode=True,temperature=None,
                       extra_body={"chat_template_kwargs":{"enable_thinking":False}})
            Client(cfg,self.trace()).doctor()
            req = captured[-1]
            self.assertEqual(req["path"],"/local/v1/chat/completions")
            self.assertIsNone(req["authorization"])
            self.assertNotIn("temperature",req["body"])
            self.assertEqual(req["body"]["response_format"],{"type":"json_object"})
            self.assertFalse(req["body"]["chat_template_kwargs"]["enable_thinking"])
    def test_429_retry(self):
        with serve(statuses=[429,200]) as (cfg,captured,_):
            c = Client(cfg,self.trace())
            c.chat("doctor",{"stage":"doctor"},"JSON")
            self.assertEqual(len(captured),2)
    def test_401_fail_fast(self):
        with serve(statuses=[401]) as (cfg,captured,_):
            with self.assertRaisesRegex(ValueError,"HTTP 401"):
                Client(cfg,self.trace()).chat("doctor",{"stage":"doctor"},"JSON")
            self.assertEqual(len(captured),1)
    def test_timeout_is_bounded(self):
        def slow(body):
            time.sleep(.15)
            return {"ok":True}
        with serve(slow) as (cfg,captured,_):
            cfg.update(timeout_seconds=.02,http_retries=0)
            with self.assertRaisesRegex(ValueError,"timed out"):
                Client(cfg,self.trace()).chat("doctor",{"stage":"doctor"},"JSON")
    def test_budget_stops_next_call(self):
        with serve() as (cfg,captured,_):
            cfg["max_http_calls"] = 1
            c = Client(cfg,self.trace())
            c.chat("doctor",{"stage":"doctor"},"JSON")
            with self.assertRaisesRegex(ValueError,"budget"):
                c.chat("doctor",{"stage":"doctor"},"JSON")
            self.assertEqual(len(captured),1)
    def test_empty_and_truncated_responses(self):
        cfg = {"base_url":"http://127.0.0.1:1/v1","model":"test"}
        c = Client(cfg,self.trace())
        for content,reason in [("", "stop"),('{"partial":',"length")]:
            with patch.object(c,"request",return_value=(
                {"choices":[{"message":{"content":content,"reasoning_content":"not final"},"finish_reason":reason}]},{})):
                with self.assertRaises(ValueError):
                    c.chat("test",{},"JSON")
    def test_controlled_fields_cannot_be_overridden(self):
        with self.assertRaises(ValueError):
            Client({"base_url":"http://127.0.0.1:1/v1","model":"x","extra_body":{"messages":[]}},self.trace())
    def test_repair_loop_stops(self):
        class BadClient:
            def chat(self,*args):
                return "not json"
        tr = self.trace()
        with self.assertRaisesRegex(ValueError,"after 2 rounds"):
            json_loop(BadClient(),tr,"bad",{},lambda p:p,2)
        self.assertEqual(len(list((tr.root/"responses").glob("*"))),2)


class EditingTests(TempCase):
    def test_outside_scope_batch_has_no_writes(self):
        with self.assertRaises(ValueError):
            apply_files(self.root,{"files":[{"path":"src/a.py","content":"ok"},{"path":"../oops","content":"bad"}]},["src/"])
        self.assertFalse((self.root/"src/a.py").exists())
    def test_symlink_rejected(self):
        outside = self.root/"outside";outside.mkdir()
        (self.root/"src").symlink_to(outside,target_is_directory=True)
        with self.assertRaises(ValueError):
            apply_files(self.root,{"files":[{"path":"src/file.py","content":"bad"}]},["src/"])
        self.assertEqual(list(outside.iterdir()),[])
    def test_protected_files_rejected_even_if_in_scope(self):
        for name in ("openspec/tasks.md",".github/workflows/ci.yml","src/.env","src/private.key"):
            with self.assertRaises(ValueError):
                apply_files(self.root,{"files":[{"path":name,"content":"bad"}]},[name])
    def test_actual_check_timeout(self):
        tr = self.trace()
        checks = [{"id":"AC1","argv":["{python}","-c","import time;time.sleep(3)"],"timeout_seconds":.05}]
        results = run_checks(checks,self.root,tr,1,"TEAMFLOW_API_KEY")
        self.assertTrue(results[0]["timed_out"])
        self.assertFalse(results[0]["passed"])
    def test_checks_must_cover_acceptance(self):
        ws = self.root/"ws";ws.mkdir()
        f = self.root/"checks.json";write_json(f,{"checks":[{"id":"AC1","argv":["python","check.py"]}]})
        with self.assertRaisesRegex(ValueError,"cover"):
            load_checks(f,["AC2"],ws)


class EndToEndTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.tmp = tempfile.TemporaryDirectory(prefix="teamflow-e2e-")
        cls.root = Path(cls.tmp.name)
        cls.result = run_demo(cls.root/"demo")
        cls.project = cls.root/"demo/project"
    @classmethod
    def tearDownClass(cls):
        cls.tmp.cleanup()
    def fresh_project(self,name):
        p = self.root/name
        shutil.copytree(self.project,p,ignore=shutil.ignore_patterns(".git",".teamflow"))
        return p
    def test_native_validation_and_feedback(self):
        self.assertEqual(self.result["native_openspec_changes_validated"],6)
        self.assertEqual(self.result["stage_request_counts"]["plan"],2)
        self.assertEqual(self.result["stage_request_counts"]["artifact-foundation-contracts"],2)
    def test_code_test_feedback_executes(self):
        self.assertEqual(self.result["development_rounds"],2)
        logs = [json.loads(x) for x in (self.root/"demo/development/events.jsonl").read_text().splitlines()]
        checks = [x for x in logs if x["event"] == "check_result"]
        self.assertEqual([x["passed"] for x in checks],[False,True])
        self.assertFalse(self.result["delivery_complete"])
        self.assertEqual(self.result["real_model_inference_calls"],0)
    def test_atomic_concurrent_claims_one_winner(self):
        p = self.fresh_project("concurrent")
        def claim(_):
            try:
                Coordinator(p).claim("foundation-contracts","D1")
                return True
            except ValueError:
                return False
        with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
            self.assertEqual(sum(pool.map(claim,range(4))),1)
    def test_dependencies_block_claim(self):
        p = self.fresh_project("dependencies")
        with self.assertRaisesRegex(ValueError,"dependencies"):
            Coordinator(p).claim("ticket-api","D2")
    def test_fingerprint_drift_blocks_packet(self):
        p = self.fresh_project("drift")
        c = Coordinator(p);claim = c.claim("foundation-contracts","D1")
        with (p/"openspec/changes/foundation-contracts/design.md").open("a") as f:
            f.write("\nChanged design\n")
        with self.assertRaisesRegex(ValueError,"fingerprint"):
            c.get_claim("foundation-contracts",claim["token"])
    def test_install_collision_preserves_target(self):
        target = self.root/"collision";(target/"teamflow").mkdir(parents=True)
        f = target/"teamflow/plan.json";f.write_text('{"keep":true}')
        bundle = self.root/"demo/planning"
        with self.assertRaisesRegex(ValueError,"collision"):
            install_bundle(bundle,target,read_json(bundle/"result.json")["bundle_sha256"])
        self.assertEqual(f.read_text(),'{"keep":true}')
        self.assertFalse((target/"openspec").exists())
    def test_stale_worker_lock_blocks_second_worker(self):
        c = Coordinator(self.project)
        db = c.db()
        row = dict(db.execute("SELECT * FROM claims").fetchone());db.close()
        lock = c.root/".teamflow/worker-foundation-contracts.lock";lock.write_text("0")
        try:
            with self.assertRaisesRegex(ValueError,"worker"):
                develop_run({},self.project,"foundation-contracts",row["token"],"unused","unused")
        finally:
            lock.unlink()
    def test_integration_receipt_cannot_unlock_without_commit(self):
        c = Coordinator(self.project)
        db = c.db()
        row = dict(db.execute("SELECT * FROM claims").fetchone());db.close()
        receipt = {"change_id":"foundation-contracts","plan_sha256":row["fingerprint"],
                   "commit":row["base_commit"],"ci_run_url":"https://example.invalid/ci/demo",
                   "reviewer":"D2","passed":True,"passed_acceptance_ids":["AC01"]}
        with self.assertRaisesRegex(ValueError,"base commit"):
            c.record_integrated("foundation-contracts",row["token"],receipt)
    def test_batch_runs_two_workers_concurrently(self):
        # A dedicated fixture variant makes UI independent solely to test concurrent execution.
        p = self.fresh_project("parallel")
        plan = read_json(p/"teamflow/plan.json")
        ui = next(t for t in plan["tasks"] if t["id"] == "ticket-ui")
        ui["depends_on"] = []
        write_json(p/"teamflow/plan.json",plan)
        handoff = read_json(p/"openspec/changes/ticket-ui/handoff.json")
        handoff["depends_on"] = []
        write_json(p/"openspec/changes/ticket-ui/handoff.json",handoff)
        git(p,"init","--initial-branch=main");git(p,"add",".")
        git(p,"-c","user.name=Test","-c","user.email=test@example.invalid","commit","-m","Independent parallel fixture")
        checks = self.root/"parallel-checks";checks.mkdir()
        for task in [plan["tasks"][0],ui]:
            file = task["paths_write"][0].rstrip("/")+"/demo.txt"
            command = "from pathlib import Path; assert Path("+repr(file)+").read_text() == 'ready'"
            write_json(checks/(task["id"]+".json"),{"checks":[{"id":task["acceptance_tests"][0],"argv":["{python}","-c",command]}]})
        barrier = threading.Barrier(2)
        arrivals = []
        def responder(body):
            payload = json.loads(body["messages"][-1]["content"])
            arrivals.append(payload["task"]["id"])
            barrier.wait(timeout=5)
            file = payload["task"]["paths_write"][0].rstrip("/")+"/demo.txt"
            return {"files":[{"path":file,"content":"ready"}]}
        with serve(responder) as (cfg,_,_):
            result = run_batch(cfg,p,checks,self.root/"parallel-trees",self.root/"parallel-runs",True)
        self.assertEqual(result["workers_started"],2)
        self.assertEqual(len(arrivals),2)
        self.assertTrue(all(r["state"] == "READY_FOR_REVIEW" for r in result["results"].values()))


if __name__ == "__main__":
    unittest.main()
