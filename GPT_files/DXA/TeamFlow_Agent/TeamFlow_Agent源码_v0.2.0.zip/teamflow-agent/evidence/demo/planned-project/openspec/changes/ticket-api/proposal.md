# 工单创建接口
## Why
实现示例工单变更的一项独立可验收工作，降低多人并行时的交接成本。
## What Changes
- 工单创建接口，对应 R02 / AC02。
## Capabilities
### New Capabilities
- ticket-api: 工单创建接口
### Modified Capabilities
- 无。
## Impact
写入范围：src/tickets/api/。本文件是待开发示例，不是完成证明。
