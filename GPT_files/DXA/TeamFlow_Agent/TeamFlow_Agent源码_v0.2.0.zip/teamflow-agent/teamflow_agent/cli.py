from __future__ import annotations
import argparse
import json
import os
from pathlib import Path
import sqlite3
import subprocess
import sys
from .common import Trace, read_json
from .llm import Client
from .workflow import plan_run, install_bundle
from .coordinator import Coordinator
from .developer import develop_run
from . import __version__


def parser():
    p = argparse.ArgumentParser(description="TeamFlow: local OpenAI-compatible agent + OpenSpec team coordination")
    p.add_argument("--version",action="version",version=__version__)
    p.add_argument("--openspec-bin",help="Path to pinned OpenSpec executable or JS entrypoint")
    subs = p.add_subparsers(dest="action",required=True)
    for name in ("doctor","plan","develop","batch"):
        s = subs.add_parser(name)
        s.add_argument("--llm",required=True,help="LLM JSON configuration; credentials use an environment variable")
        s.add_argument("--out",required=True,help="New output directory")
        if name in ("plan","develop","batch"):
            s.add_argument("--max-rounds",type=int,default=3)
        if name == "plan":
            s.add_argument("--design",required=True)
            s.add_argument("--requirements",required=True)
            s.add_argument("--team",required=True)
            s.add_argument("--context-chars",type=int,default=60000)
        if name == "develop":
            s.add_argument("--project",required=True)
            s.add_argument("--change",required=True)
            s.add_argument("--token",required=True)
            s.add_argument("--checks",required=True)
            s.add_argument("--execute-checks",action="store_true")
        if name == "batch":
            s.add_argument("--project",required=True)
            s.add_argument("--checks-dir",required=True)
            s.add_argument("--worktrees",required=True)
            s.add_argument("--execute-checks",action="store_true")
    s = subs.add_parser("install")
    s.add_argument("--bundle",required=True)
    s.add_argument("--project",required=True)
    s.add_argument("--approve",required=True,help="SHA-256 from reviewed plan result")
    s = subs.add_parser("demo")
    s.add_argument("--out",required=True)
    for name in ("status","claim","packet","workspace","record-integrated","release"):
        s = subs.add_parser(name)
        s.add_argument("--project",required=True)
        if name != "status":
            s.add_argument("--change",required=True)
        if name == "claim":
            s.add_argument("--member",required=True)
        elif name != "status":
            s.add_argument("--token",required=True)
        if name == "workspace":
            s.add_argument("--destination",required=True)
        if name == "record-integrated":
            s.add_argument("--receipt",required=True)
        if name == "release":
            s.add_argument("--reason",required=True)
    return p


def main(argv=None):
    args = parser().parse_args(argv)
    settings = {}
    try:
        if args.openspec_bin:
            os.environ["OPENSPEC_BIN"] = str(Path(args.openspec_bin).resolve())
        if hasattr(args,"llm"):
            settings = read_json(args.llm)
        if args.action == "doctor":
            trace = Trace(args.out)
            result = Client(settings,trace).doctor()
            trace.save("result.json",result)
        elif args.action == "plan":
            result = plan_run(settings,args.design,read_json(args.requirements),read_json(args.team),args.out,
                              args.max_rounds,args.context_chars)
        elif args.action == "install":
            result = install_bundle(args.bundle,args.project,args.approve)
        elif args.action == "develop":
            result = develop_run(settings,args.project,args.change,args.token,args.checks,args.out,
                                 args.max_rounds,args.execute_checks)
        elif args.action == "batch":
            from .batch import run_batch
            result = run_batch(settings,args.project,args.checks_dir,args.worktrees,args.out,
                               args.execute_checks,args.max_rounds)
        elif args.action == "demo":
            from .demo import run_demo
            result = run_demo(args.out)
        else:
            c = Coordinator(args.project)
            if args.action == "status":
                result = c.states()
            elif args.action == "claim":
                result = c.claim(args.change,args.member)
            elif args.action == "packet":
                result = c.packet(args.change,args.token)
            elif args.action == "workspace":
                result = c.workspace(args.change,args.token,args.destination)
            elif args.action == "record-integrated":
                result = c.record_integrated(args.change,args.token,read_json(args.receipt))
            else:
                result = c.release(args.change,args.token,args.reason)
        print(json.dumps(result,ensure_ascii=False,indent=2))
        return 0
    except (ValueError, OSError, KeyError, TypeError, sqlite3.Error, subprocess.TimeoutExpired) as exc:
        error = str(exc)
        key = os.environ.get(settings.get("api_key_env","TEAMFLOW_API_KEY"),"")
        if key:
            error = error.replace(key,"[REDACTED]")
        print(json.dumps({"error":error},ensure_ascii=False),file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
