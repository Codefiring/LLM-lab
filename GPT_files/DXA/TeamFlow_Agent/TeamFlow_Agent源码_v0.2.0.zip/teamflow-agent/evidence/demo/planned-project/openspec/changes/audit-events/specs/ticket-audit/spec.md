## Purpose
This capability defines observable ticketing behavior shared by the pilot team and provides a stable basis for independent implementation and acceptance.
## ADDED Requirements
### Requirement: 工单审计事件
The audit service SHALL retain a tenant-scoped create event with actor, ticket ID and event ID, and deduplicate retried events.
#### Scenario: AC04
- **WHEN** the same creation event is delivered twice
- **THEN** exactly one audit entry is stored and another tenant cannot read it
