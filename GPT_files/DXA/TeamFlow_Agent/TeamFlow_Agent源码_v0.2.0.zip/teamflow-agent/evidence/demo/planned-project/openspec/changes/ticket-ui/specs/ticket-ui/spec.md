## Purpose
This capability defines observable ticketing behavior shared by the pilot team and provides a stable basis for independent implementation and acceptance.
## ADDED Requirements
### Requirement: 工单创建页面
The interface SHALL let a signed-in user create a ticket, display input validation and preserve entered content on recoverable failures.
#### Scenario: AC03
- **WHEN** submission fails with a recoverable service error
- **THEN** the form preserves input and permits a retry without creating duplicate tickets
