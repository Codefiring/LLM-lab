"""Run one dependency-ready wave, at most one worker for each scheduled human owner."""
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path
from .common import TeamFlowError, write_json
from .coordinator import Coordinator
from .developer import develop_run, load_checks
from .planning import schedule


def run_batch(settings, project, checks_dir, worktrees, out, execute_checks=False, rounds=3):
    if not execute_checks:
        raise TeamFlowError("batch execution requires --execute-checks")
    c = Coordinator(project)
    output = Path(out).resolve()
    trees = Path(worktrees).resolve()
    if output.is_relative_to(c.root) or trees.is_relative_to(c.root):
        raise TeamFlowError("batch output and worktrees must be outside the coordinator repository")
    output.mkdir(parents=True,exist_ok=False)
    assignments = schedule(c.plan,c.manifest,c.team)["assignments"]
    active = {x["change_id"] for x in c.states()["claims"]}
    prepared, skipped, owners = [], [], set()
    for row in assignments:
        tid, owner = row["task_id"],row["owner"]
        if tid in active or owner in owners:
            continue
        checks = Path(checks_dir).resolve() / (tid+".json")
        if not checks.is_file():
            skipped.append({"change_id":tid,"reason":"missing operator check configuration"})
            continue
        # Validate before acquiring a claim; an unstarted workspace path suffices here.
        try:
            load_checks(checks,c.tasks[tid]["acceptance_tests"],trees/tid)
            claim = c.claim(tid,owner)
        except ValueError as exc:
            skipped.append({"change_id":tid,"reason":str(exc)})
            continue
        try:
            workspace = c.workspace(tid,claim["token"],trees/(tid+"-"+claim["token"][:8]))
        except Exception:
            c.release(tid,claim["token"],"worktree setup failed before worker start")
            raise
        prepared.append((tid,claim["token"],checks,workspace))
        owners.add(owner)
    results = {}
    with ThreadPoolExecutor(max_workers=max(1,len(c.members))) as pool:
        futures = {pool.submit(develop_run,settings,c.root,tid,token,checks,output/tid,rounds,True):tid
                   for tid,token,checks,_ in prepared}
        for future in as_completed(futures):
            tid = futures[future]
            try:
                results[tid] = future.result()
            except Exception as exc:
                # Worker trace contains details; do not echo possibly secret-bearing provider text.
                results[tid] = {"state":"BLOCKED","error_type":type(exc).__name__,"trace":str(output/tid)}
    result = {"state":"WAVE_FINISHED","workers_started":len(prepared),"team_size":len(c.members),
              "results":results,"skipped":skipped,"delivery_complete":False,
              "next":"Review each worker output; integrate and attest accepted commits before starting the next wave."}
    write_json(output/"result.json",result)
    return result
