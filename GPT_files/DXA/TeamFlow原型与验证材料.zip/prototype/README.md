# TeamFlow 团队 AI 开发规划原型

把需求清单、项目设计和 N 名成员资料转成任务包、依赖关系及人员排程。目标是支撑“人负责、AI 执行”的协作方式。

本包是**规划层参考原型**，不是已完成的多人自动开发平台。它不会运行生成的测试、创建工作区、写业务代码或合并 PR。

## 已实现与验证范围

- 按需求编号检查任务及验收编号覆盖；验证依赖无环、任务大小和成员技能。
- 按关键路径优先排程，限制每人同时一个任务，处理声明的文件前缀及共享资源互斥。
- 输出每项任务的负责人、预计起止时间和任务包。
- 通过操作人员提供的命令调用模型；计划不合法时，将校验反馈送回模型，最多重试指定次数。
- 保留候选计划、事件日志和调度输出；输出目录必须为新目录，避免覆盖旧证据。

本次实测使用人工编制的示例和确定性 provider 替身；18 项机制检查通过。**真实 LLM 调用 0 次，真实团队参与人数 0。** 不能据此认定业务提效目标达成。

## 环境

Python 3.10 或更高版本；核心原型仅依赖标准库。以下命令在本目录执行。输出目录已存在时，请换一个新名称。

## 直接运行排程

```bash
python teamflow.py schedule \
  --manifest examples/requirements.json \
  --team examples/team.json \
  --plan examples/plan.json \
  --output runs/my-first-plan
```

人数由 `team.json` 的 `members` 数量确定。调整人数时提供真实的成员能力，不应把匿名“全能成员”当成真实团队资料。示例工时单位是人时；当前版本假设成员全时可用、相同处理速度，未实现日历和兼职容量。

输出：`plan.json`、`schedule.json`、`events.jsonl`、`taskpacks/*.md`。

## 接入真实规划模型

程序从 stdin 向指定命令发送规划请求，该命令须从 stdout 返回计划 JSON。支持直接 JSON、JSON 代码块和 Claude Code 的 `result` 或 `structured_output` 包装。

在已安装、登录且具备可用模型访问权限的 Claude Code 环境，可以使用以下命令。这个接入示例依据官方 CLI 文档编写，**本次没有验证真实服务连通性或模型输出质量**。

```bash
python teamflow.py agent \
  --manifest examples/requirements.json \
  --team examples/team.json \
  --design examples/design.md \
  --command-json '["claude","-p","--output-format","json","--tools","","--disallowedTools","mcp__*"]' \
  --output runs/live-plan \
  --max-rounds 3 --timeout 120
```

这里关闭内置工具和 MCP 工具，只做设计文本到计划的转换。正式产品的大工程检索阶段需另设只读仓库索引器；不要把整个仓库无限塞入一次提示词。也可以用企业内部模型网关脚本替代上述命令，保持 stdin/stdout 协议即可。

供应商命令属于操作人员配置，使用 `shell=False` 执行；模型生成的命令不会执行。生产环境仍须对 provider 进程设置容器隔离、完整进程树超时、输出大小和预算限制。

## 复现本地检查

```bash
python evaluate.py runs/local-verification-new
```

检查项包括 12 项无效输入拒绝、4 种排程、一次反馈修复、一次达到重试上限停止。`fixture_provider.py` 会故意先返回错误依赖，再根据反馈返回固定正确示例；它不是 LLM，也不代表自然语言理解效果。

原始本次结果位于 `evidence/local-verification/verification.json`。`evaluation_protocol.json` 是运行前定义的机制验收标准，验证结果记录其 SHA-256。排程表里的 46、32、32 小时是**输入工时推算值**，不是开发过程计时。

## 从原型到试点仍需实现

1. 带来源定位的文档分层解析、仓库索引和语义审查，校验需求是否被正确理解。
2. 人员工作日历、技能偏好、任务估算区间、实际进度反馈和局部重排。
3. Git worktree 或容器、Coding Agent、PR/CI、契约注册表、集成队列。
4. 持久化状态机、任务租约、幂等执行和中断恢复。
5. 真实人时、等待时间、模型费用和缺陷的自动采集及对照试点。

结构覆盖率不代表实现正确；声明的路径互斥不代表运行时访问隔离；计划生成成功不代表任务已开发完成。所有业务结果须在真实仓库中通过冻结验收测试和人工评审。

## 参考

- [Claude Code 程序化运行](https://code.claude.com/docs/en/headless)
- [Claude Code CLI 参数](https://code.claude.com/docs/en/cli-reference)
- [LangGraph 持久化](https://docs.langchain.com/oss/python/langgraph/persistence)
- [Git worktree](https://git-scm.com/docs/git-worktree)
