from __future__ import annotations
import json
import os
from pathlib import Path
import shutil
import subprocess
from .common import TeamFlowError


def invoke(root, *args, binary=None):
    root = Path(root).resolve()
    supplied = binary or os.environ.get("OPENSPEC_BIN")
    candidates = ([Path(supplied)] if supplied else []) + [
        root / "node_modules/.bin/openspec",
        Path.cwd() / "node_modules/.bin/openspec",
    ]
    executable = next((str(p.resolve()) for p in candidates if p.is_file()), None)
    executable = executable or shutil.which(supplied or "openspec")
    if not executable:
        # npm on Windows creates .cmd launchers; invoke the underlying JS without shell=True.
        candidates = [root, Path.cwd()]
        js = next((p / "node_modules/@fission-ai/openspec/bin/openspec.js" for p in candidates
                   if (p / "node_modules/@fission-ai/openspec/bin/openspec.js").is_file()), None)
        if not js:
            raise TeamFlowError("OpenSpec not found: run npm ci in the source directory or set OPENSPEC_BIN")
        executable = str(js)
    argv = (["node", executable] if executable.endswith((".js", ".mjs")) else [executable]) + list(args)
    env = {**os.environ, "OPENSPEC_TELEMETRY":"0", "DO_NOT_TRACK":"1"}
    r = subprocess.run(argv, cwd=root, env=env, capture_output=True, text=True,
                       encoding="utf-8", errors="replace", timeout=60, shell=False)
    if r.returncode:
        raise TeamFlowError(f"OpenSpec failed: {r.stdout[-6000:]}\n{r.stderr[-2000:]}")
    try:
        return json.loads(r.stdout)
    except json.JSONDecodeError:
        raise TeamFlowError("OpenSpec did not return JSON; use the pinned version 1.13.1") from None


def ready(root, change, binary=None):
    status = invoke(root, "status", "--change", change, "--json", binary=binary)
    if not status.get("isPlanningComplete", status.get("isComplete", False)):
        raise TeamFlowError(f"{change}: planning artifacts incomplete")
    validation = invoke(root, "validate", change, "--strict", "--no-interactive", "--json", binary=binary)
    return {"status":status, "validation":validation}
