#!/usr/bin/env python3
"""
Generate a visual HTML report summarizing Git commits within a date range.

Example:
  python commit_summary_report.py \
    --repo /path/to/repo \
    --since "2026-05-01" \
    --until "2026-05-31 23:59:59" \
    --output commit_summary.html
"""

from __future__ import annotations

import argparse
import collections
import dataclasses
import datetime as dt
import html
import json
import os
import re
import subprocess
import sys
from pathlib import Path
from typing import Dict, List, Optional, Tuple


@dataclasses.dataclass
class FileChange:
    path: str
    additions: int
    deletions: int


@dataclasses.dataclass
class Commit:
    hash: str
    short_hash: str
    author: str
    email: str
    date: str
    subject: str
    body: str
    files: List[FileChange]
    modules: List[str]
    category: str
    feature_hint: str


def run_git(repo: Path, args: List[str]) -> str:
    try:
        proc = subprocess.run(
            ["git", "-C", str(repo), *args],
            check=True,
            text=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
        )
        return proc.stdout
    except FileNotFoundError:
        raise RuntimeError("git command not found. Please install Git and try again.")
    except subprocess.CalledProcessError as exc:
        raise RuntimeError(exc.stderr.strip() or f"git failed: {' '.join(args)}")


def assert_git_repo(repo: Path) -> None:
    if not repo.exists():
        raise RuntimeError(f"Repository path does not exist: {repo}")
    out = run_git(repo, ["rev-parse", "--is-inside-work-tree"]).strip()
    if out != "true":
        raise RuntimeError(f"Not a Git repository: {repo}")


def current_branch(repo: Path) -> str:
    try:
        return run_git(repo, ["rev-parse", "--abbrev-ref", "HEAD"]).strip()
    except RuntimeError:
        return "HEAD"


def parse_numstat(output: str) -> List[FileChange]:
    changes: List[FileChange] = []
    for line in output.splitlines():
        parts = line.split("\t")
        if len(parts) < 3:
            continue
        add_s, del_s, path = parts[0], parts[1], parts[2]
        additions = int(add_s) if add_s.isdigit() else 0
        deletions = int(del_s) if del_s.isdigit() else 0
        changes.append(FileChange(path=path, additions=additions, deletions=deletions))
    return changes


def infer_module(path: str) -> str:
    p = path.replace("\\", "/")
    parts = [x for x in p.split("/") if x]
    if not parts:
        return "root"
    if parts[0] in {"src", "app", "packages", "services"} and len(parts) > 1:
        return "/".join(parts[:2])
    return parts[0]


def infer_category(subject: str, files: List[FileChange]) -> str:
    s = subject.lower().strip()
    prefix = re.match(r"^(feat|fix|refactor|docs|test|chore|perf|security|style|ci|build)(\(.+?\))?:", s)
    if prefix:
        mapping = {
            "feat": "Feature",
            "fix": "Bug Fix",
            "refactor": "Refactor",
            "docs": "Documentation",
            "test": "Testing",
            "chore": "Maintenance",
            "perf": "Performance",
            "security": "Security",
            "style": "Style",
            "ci": "CI/CD",
            "build": "Build",
        }
        return mapping.get(prefix.group(1), prefix.group(1).title())

    paths = " ".join(f.path.lower() for f in files)
    if any(x in paths for x in ["test", "spec", "pytest"]):
        return "Testing"
    if any(x in paths for x in ["doc", "readme", "mkdocs"]):
        return "Documentation"
    if any(x in paths for x in ["auth", "permission", "jwt", "oauth"]):
        return "Auth / Permission"
    if any(x in paths for x in ["security", "vuln", "scan", "policy"]):
        return "Security"
    if any(x in paths for x in ["ui", "frontend", "components", "pages"]):
        return "Frontend/UI"
    if any(x in paths for x in ["api", "server", "backend", "router", "controller"]):
        return "Backend/API"
    if any(x in paths for x in ["db", "database", "migration", "schema"]):
        return "Database"
    if any(x in s for x in ["fix", "bug", "error", "issue"]):
        return "Bug Fix"
    if any(x in s for x in ["add", "support", "implement", "create"]):
        return "Feature"
    return "General Change"


def clean_subject_to_feature(subject: str) -> str:
    s = re.sub(r"^(feat|fix|refactor|docs|test|chore|perf|security|style|ci|build)(\(.+?\))?:\s*", "", subject, flags=re.I)
    return s[:1].upper() + s[1:] if s else subject


def collect_commits(repo: Path, since: str, until: str, branch: Optional[str], include_merges: bool) -> Tuple[str, List[Commit]]:
    ref = branch or "HEAD"
    args = ["log", ref, f"--since={since}", f"--until={until}", "--date=iso-strict", "--pretty=format:%H%x1f%h%x1f%an%x1f%ae%x1f%ad%x1f%s%x1f%b%x1e"]
    if not include_merges:
        args.insert(2, "--no-merges")
    raw = run_git(repo, args)

    commits: List[Commit] = []
    for rec in raw.split("\x1e"):
        rec = rec.strip("\n")
        if not rec.strip():
            continue
        parts = rec.split("\x1f")
        if len(parts) < 7:
            continue
        full_hash, short_hash, author, email, date, subject, body = parts[:7]
        numstat = run_git(repo, ["show", "--numstat", "--format=", full_hash])
        files = parse_numstat(numstat)
        modules = sorted({infer_module(f.path) for f in files})
        category = infer_category(subject, files)
        feature_hint = clean_subject_to_feature(subject)
        commits.append(
            Commit(
                hash=full_hash,
                short_hash=short_hash,
                author=author,
                email=email,
                date=date,
                subject=subject,
                body=body.strip(),
                files=files,
                modules=modules,
                category=category,
                feature_hint=feature_hint,
            )
        )
    return ref, commits


def summarize(commits: List[Commit]) -> Dict:
    total_add = sum(f.additions for c in commits for f in c.files)
    total_del = sum(f.deletions for c in commits for f in c.files)
    category_counts = collections.Counter(c.category for c in commits)
    author_counts = collections.Counter(c.author for c in commits)
    module_counts = collections.Counter(m for c in commits for m in c.modules)

    file_impact: Dict[str, Dict[str, int]] = collections.defaultdict(lambda: {"commits": 0, "additions": 0, "deletions": 0})
    for c in commits:
        seen = set()
        for f in c.files:
            if f.path not in seen:
                file_impact[f.path]["commits"] += 1
                seen.add(f.path)
            file_impact[f.path]["additions"] += f.additions
            file_impact[f.path]["deletions"] += f.deletions

    top_files = sorted(
        [{"path": k, **v} for k, v in file_impact.items()],
        key=lambda x: (x["commits"], x["additions"] + x["deletions"]),
        reverse=True,
    )[:50]

    return {
        "total_commits": len(commits),
        "total_additions": total_add,
        "total_deletions": total_del,
        "category_counts": dict(category_counts),
        "author_counts": dict(author_counts),
        "module_counts": dict(module_counts),
        "top_files": top_files,
    }


def esc(s: object) -> str:
    return html.escape(str(s), quote=True)


def render_bar(label: str, value: int, max_value: int) -> str:
    width = 0 if max_value == 0 else int(value / max_value * 100)
    return f"""
    <div class='bar-row'>
      <div class='bar-label'>{esc(label)}</div>
      <div class='bar-track'><div class='bar-fill' style='width:{width}%'></div></div>
      <div class='bar-value'>{value}</div>
    </div>
    """


def render_html(repo: Path, ref: str, since: str, until: str, commits: List[Commit]) -> str:
    stats = summarize(commits)
    generated_at = dt.datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    max_cat = max(stats["category_counts"].values(), default=0)
    max_author = max(stats["author_counts"].values(), default=0)
    max_module = max(stats["module_counts"].values(), default=0)

    category_bars = "\n".join(render_bar(k, v, max_cat) for k, v in sorted(stats["category_counts"].items(), key=lambda x: x[1], reverse=True))
    author_bars = "\n".join(render_bar(k, v, max_author) for k, v in sorted(stats["author_counts"].items(), key=lambda x: x[1], reverse=True))
    module_bars = "\n".join(render_bar(k, v, max_module) for k, v in sorted(stats["module_counts"].items(), key=lambda x: x[1], reverse=True)[:20])

    feature_groups: Dict[str, List[Commit]] = collections.defaultdict(list)
    for c in commits:
        feature_groups[c.category].append(c)

    feature_cards = []
    for category, items in sorted(feature_groups.items(), key=lambda x: len(x[1]), reverse=True):
        hints = "".join(f"<li><b>{esc(c.short_hash)}</b> {esc(c.feature_hint)} <span class='muted'>({esc(', '.join(c.modules) or 'no files')})</span></li>" for c in items[:10])
        more = f"<p class='muted'>... and {len(items)-10} more commits</p>" if len(items) > 10 else ""
        feature_cards.append(f"""
        <section class='card feature-card'>
          <h3>{esc(category)}</h3>
          <p class='metric-line'>{len(items)} commit(s)</p>
          <ul>{hints}</ul>
          {more}
        </section>
        """)

    file_rows = "\n".join(
        f"<tr><td>{esc(f['path'])}</td><td>{f['commits']}</td><td>+{f['additions']}</td><td>-{f['deletions']}</td></tr>"
        for f in stats["top_files"]
    )

    commit_cards = []
    for c in commits:
        file_list = "".join(f"<li>{esc(f.path)} <span class='plus'>+{f.additions}</span> <span class='minus'>-{f.deletions}</span></li>" for f in c.files[:20])
        more_files = f"<li class='muted'>... and {len(c.files)-20} more files</li>" if len(c.files) > 20 else ""
        body = f"<pre>{esc(c.body)}</pre>" if c.body else ""
        commit_cards.append(f"""
        <details class='commit-detail'>
          <summary><b>{esc(c.short_hash)}</b> {esc(c.subject)} <span class='badge'>{esc(c.category)}</span></summary>
          <div class='commit-meta'>{esc(c.author)} &lt;{esc(c.email)}&gt; · {esc(c.date)}</div>
          <div class='commit-meta'>Modules: {esc(', '.join(c.modules) or 'N/A')}</div>
          {body}
          <ul class='file-list'>{file_list}{more_files}</ul>
        </details>
        """)

    data = json.dumps({
        "repo": str(repo),
        "ref": ref,
        "since": since,
        "until": until,
        "stats": stats,
        "commits": [dataclasses.asdict(c) for c in commits],
    }, ensure_ascii=False, indent=2)

    if not commits:
        no_commit_message = "<div class='empty'>No commits found in the selected time range.</div>"
    else:
        no_commit_message = ""

    return f"""<!doctype html>
<html lang='en'>
<head>
<meta charset='utf-8'>
<meta name='viewport' content='width=device-width, initial-scale=1'>
<title>Git Commit Summary Report</title>
<style>
:root {{ --bg:#f6f7fb; --card:#ffffff; --text:#172033; --muted:#667085; --border:#e6e8ef; --fill:#3b82f6; --good:#15803d; --bad:#b91c1c; }}
* {{ box-sizing: border-box; }}
body {{ margin:0; font-family: Inter, -apple-system, BlinkMacSystemFont, 'Segoe UI', Arial, sans-serif; background:var(--bg); color:var(--text); }}
header {{ padding:36px 48px; background:linear-gradient(135deg,#111827,#1f2937); color:white; }}
header h1 {{ margin:0 0 10px; font-size:32px; }}
header p {{ margin:4px 0; color:#d1d5db; }}
main {{ padding:28px 48px 60px; max-width:1440px; margin:0 auto; }}
.grid {{ display:grid; gap:18px; }}
.grid-4 {{ grid-template-columns: repeat(4, minmax(0,1fr)); }}
.grid-3 {{ grid-template-columns: repeat(3, minmax(0,1fr)); }}
.card {{ background:var(--card); border:1px solid var(--border); border-radius:16px; padding:18px; box-shadow: 0 8px 24px rgba(16,24,40,.04); }}
.metric {{ font-size:30px; font-weight:800; margin:8px 0 0; }}
.metric-line {{ color:var(--muted); font-weight:600; }}
.muted {{ color:var(--muted); }}
section {{ margin-top:22px; }}
h2 {{ margin:0 0 14px; font-size:22px; }}
h3 {{ margin:0 0 10px; }}
.bar-row {{ display:grid; grid-template-columns: 170px 1fr 50px; gap:10px; align-items:center; margin:10px 0; }}
.bar-label {{ color:var(--text); overflow:hidden; text-overflow:ellipsis; white-space:nowrap; }}
.bar-track {{ height:10px; background:#eef2ff; border-radius:999px; overflow:hidden; }}
.bar-fill {{ height:100%; background:var(--fill); border-radius:999px; }}
.bar-value {{ text-align:right; color:var(--muted); }}
ul {{ padding-left:20px; }}
li {{ margin:6px 0; }}
table {{ width:100%; border-collapse:collapse; background:white; border-radius:12px; overflow:hidden; }}
th, td {{ padding:10px 12px; border-bottom:1px solid var(--border); text-align:left; font-size:14px; }}
th {{ background:#f8fafc; color:#475467; }}
.commit-detail {{ background:white; border:1px solid var(--border); border-radius:12px; padding:12px 14px; margin:10px 0; }}
.commit-detail summary {{ cursor:pointer; }}
.badge {{ display:inline-block; margin-left:8px; padding:2px 8px; border-radius:999px; background:#eff6ff; color:#1d4ed8; font-size:12px; }}
.commit-meta {{ margin:8px 0; color:var(--muted); font-size:14px; }}
.file-list {{ columns: 2; }}
.plus {{ color:var(--good); }}
.minus {{ color:var(--bad); }}
pre {{ background:#0b1020; color:#d1d5db; border-radius:10px; padding:12px; overflow:auto; }}
.empty {{ padding:30px; text-align:center; color:var(--muted); background:white; border:1px dashed var(--border); border-radius:16px; }}
footer {{ margin-top:30px; color:var(--muted); font-size:13px; }}
@media (max-width: 900px) {{ .grid-4,.grid-3 {{ grid-template-columns: 1fr; }} main, header {{ padding-left:20px; padding-right:20px; }} .bar-row {{ grid-template-columns: 1fr; }} .file-list {{ columns: 1; }} }}
</style>
</head>
<body>
<header>
  <h1>Git Commit Summary Report</h1>
  <p>Repository: {esc(repo)}</p>
  <p>Ref: {esc(ref)} · Time range: {esc(since)} → {esc(until)}</p>
  <p>Generated at: {esc(generated_at)}</p>
</header>
<main>
  <section class='grid grid-4'>
    <div class='card'><div class='muted'>Commits</div><div class='metric'>{stats['total_commits']}</div></div>
    <div class='card'><div class='muted'>Additions</div><div class='metric plus'>+{stats['total_additions']}</div></div>
    <div class='card'><div class='muted'>Deletions</div><div class='metric minus'>-{stats['total_deletions']}</div></div>
    <div class='card'><div class='muted'>Modules touched</div><div class='metric'>{len(stats['module_counts'])}</div></div>
  </section>

  {no_commit_message}

  <section>
    <h2>Implemented Function / Change Groups</h2>
    <div class='grid grid-3'>
      {''.join(feature_cards)}
    </div>
  </section>

  <section class='grid grid-3'>
    <div class='card'><h2>Change Categories</h2>{category_bars}</div>
    <div class='card'><h2>Authors</h2>{author_bars}</div>
    <div class='card'><h2>Impacted Modules</h2>{module_bars}</div>
  </section>

  <section class='card'>
    <h2>Top Impacted Files</h2>
    <table>
      <thead><tr><th>File</th><th>Commits</th><th>Additions</th><th>Deletions</th></tr></thead>
      <tbody>{file_rows}</tbody>
    </table>
  </section>

  <section>
    <h2>Commit Details</h2>
    {''.join(commit_cards)}
  </section>

  <section class='card'>
    <h2>Raw Report Data</h2>
    <details><summary>Show JSON</summary><pre>{esc(data)}</pre></details>
  </section>

  <footer>Generated by git-commit-summary-html skill.</footer>
</main>
</body>
</html>"""


def main(argv: Optional[List[str]] = None) -> int:
    parser = argparse.ArgumentParser(description="Generate a visual HTML report for commits in a Git date range.")
    parser.add_argument("--repo", required=True, help="Path to local Git repository")
    parser.add_argument("--since", required=True, help="Start date/time accepted by git --since")
    parser.add_argument("--until", required=True, help="End date/time accepted by git --until")
    parser.add_argument("--branch", default=None, help="Branch/ref to analyze. Default: HEAD")
    parser.add_argument("--output", default="commit_summary.html", help="Output HTML path")
    parser.add_argument("--include-merges", action="store_true", help="Include merge commits")
    args = parser.parse_args(argv)

    repo = Path(args.repo).resolve()
    assert_git_repo(repo)
    ref, commits = collect_commits(repo, args.since, args.until, args.branch, args.include_merges)
    html_text = render_html(repo, ref, args.since, args.until, commits)

    output = Path(args.output).resolve()
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(html_text, encoding="utf-8")
    print(f"Report written to: {output}")
    print(f"Commits analyzed: {len(commits)}")
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except RuntimeError as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        raise SystemExit(1)
