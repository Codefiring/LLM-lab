# 工单审计事件
## Why
实现示例工单变更的一项独立可验收工作，降低多人并行时的交接成本。
## What Changes
- 工单审计事件，对应 R04 / AC04。
## Capabilities
### New Capabilities
- ticket-audit: 工单审计事件
### Modified Capabilities
- 无。
## Impact
写入范围：src/tickets/audit/。本文件是待开发示例，不是完成证明。
