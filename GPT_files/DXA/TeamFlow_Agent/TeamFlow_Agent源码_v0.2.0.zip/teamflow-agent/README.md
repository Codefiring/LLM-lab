# TeamFlow Agent

基于 OpenSpec 的团队任务规划与 AI 并行开发 Agent，版本 **0.2.0**，MIT 许可。

输入需求清单、设计文本和 N 名成员的技能，LLM 生成工作包，程序校验依赖/覆盖/路径并分派负责人；生成原生 OpenSpec 产物；在隔离 Git worktree 内执行“生成代码 → 实际测试 → 反馈修正”。`batch` 每波最多启动 N 个 Worker，每位成员最多承担一个活动任务。人工审核与集成确认后再解锁下游。

**交付状态：可运行 MVP。** 真实自动化机制测试已运行，结果见 `evidence/`。演示调用确定性 HTTP 测试替身，不做模型推理；尚无用户本地模型实测或真实团队提效数据。未建立公开代码仓库；本包提供完整可发布源码，不能填写虚构 GitHub 地址。

## 1. 安装和一键演示

需要 Python 3.10+、Node.js 20.19+、Git。实测环境为 Linux、Python 3.12.14、Node.js 24.19.0；Windows/macOS 尚未实测。Python 运行时只使用标准库。构建安装需要 setuptools，OpenSpec 通过 npm 锁定为 1.13.1。

在解压后的 `teamflow-agent` 目录执行：

```bash
python -m venv .venv
source .venv/bin/activate
python -m pip install .
npm ci --ignore-scripts --no-audit --no-fund
teamflow --version
teamflow demo --out ../runs/demo-001
```

PowerShell 激活虚拟环境用 `.\.venv\Scripts\Activate.ps1`；其余命令相同。也可不安装 Python 包，在源码根目录用 `python -m teamflow_agent` 替代 `teamflow`。从其他目录启动时，指定 `OPENSPEC_BIN`，或将全局选项 `--openspec-bin /absolute/path/to/openspec` 放在子命令前。

演示会启动仅监听回环地址的临时 OpenAI 兼容 HTTP 服务，注入三种错误：计划自依赖、空契约文档、错误 Python 实现。Agent 获取真实校验/测试错误后重试。演示创建 Git worktree 并实际运行 5 条契约示例断言。6 个业务包仅规划完成，其中一个包执行了小型契约代码示例；这不代表工单系统已开发完成。演示绝不调用外部 LLM。

查看 `../runs/demo-001/demo-result.json`、`planning/trace/events.jsonl` 和 `development/checks/`。演示重复执行需要新输出目录。

## 2. 接入本地 OpenAI-like 模型

复制 `config/llm.local.example.json` 为 `config/llm.local.json`，修改：

```json
{
  "base_url": "http://127.0.0.1:8000/v1",
  "model": "YOUR_SERVED_MODEL_NAME",
  "api_key_env": "TEAMFLOW_API_KEY",
  "timeout_seconds": 120,
  "http_retries": 2,
  "retry_delay_seconds": 1,
  "max_tokens": 8192,
  "temperature": 0.1,
  "json_mode": false,
  "max_http_calls": 80,
  "max_reported_tokens": 200000,
  "extra_body": {}
}
```

`base_url` 是 API 根地址，通常以 `/v1` 结尾；程序在其后追加 `/chat/completions`。支持带反向代理前缀的路径。如果传入完整 `/chat/completions` URL，也会规范化。`model` 必须使用本地服务实际提供的模型 ID。Ollama 本地示例地址为 `http://127.0.0.1:11434/v1`，vLLM 常见地址为 `http://127.0.0.1:8000/v1`，端口以实际部署为准。

服务需要密钥时，在终端设置 `TEAMFLOW_API_KEY`（Linux/macOS：`export TEAMFLOW_API_KEY='你的密钥'`；PowerShell：`$env:TEAMFLOW_API_KEY='你的密钥'`）。无鉴权服务可将 `api_key_env` 设为空字符串。不要把密钥写进 JSON 或源码。环境变量 `TEAMFLOW_BASE_URL`、`TEAMFLOW_MODEL` 可以覆盖配置。

```bash
teamflow doctor --llm config/llm.local.json --out ../runs/doctor-001
```

doctor 尝试 `/models` 并实际调用聊天接口验证 JSON 返回；模型列表不可用不阻止聊天检查。返回 `chat_ok: true` 才说明该配置连通并能完成最小 JSON 指令。`usage.test_double_observed` 会标识本工具演示服务器，不能据此认证其他服务器的真实身份。

本实现使用非流式 Chat Completions 和 JSON 指令，不需要 function calling、不调用 `/responses`，不含模型权重。`json_mode: true` 会发送 `response_format: {"type":"json_object"}`，仅在服务支持时开启。模型不接受 temperature 时设为 `null`。需要 `max_completion_tokens` 时将 `token_limit_field` 设为该值。

`extra_body` 原样传递服务支持的扩展字段，例如某些 vLLM 模型的 `chat_template_kwargs`；其有效性取决于服务和模型模板。模型正文前的完整 `<think>...</think>`、单个 JSON Markdown 围栏可解析；只有 `reasoning_content` 或输出被截断时失败，不会把推理内容当作最终产物。

HTTP 408/429/500/502/503/504 和连接超时可重试；401 等非暂时错误直接失败。默认不使用环境代理且拒绝重定向，防止本地请求意外转发；确需代理可显式配置 `trust_environment_proxy: true`。没有云端回退。

## 3. 输入和规划

三个输入的可运行例子在 `examples/ticketing/`：

- `source-design.md`：设计正文；也可指定包含 md/txt/json/yaml/yml 的目录。最多 500 个文件，每文件最多 1 MiB。
- `requirements.json`：权威需求 ID、设计来源、验收 ID。Agent 不自行删改权威清单。
- `members.json`：成员 ID 和技能。**成员数组长度就是指定人数 N**。增加人数必须增加真实成员记录；技能名称应与工程实际一致。

```bash
teamflow plan --llm config/llm.local.json \
  --design examples/ticketing/source-design.md \
  --requirements examples/ticketing/requirements.json \
  --team examples/ticketing/members.json \
  --out ../runs/plan-001
```

计划默认最多 3 轮修正，可用 `--max-rounds 1..6`。最多 100 个任务，每个估时大于 0 且不超过 16 小时。设计按关键词选取带行号的文本块，默认 60000 字符，可用 `--context-chars` 调整。`context_truncated: true` 表示未完整输入模型，需要负责人复核或按业务域分批。不是全工程语义理解保证。

`result.json` 中 `state: READY_FOR_REVIEW` 仅表示规划和原生校验通过。`project/` 是待审核生成目录，包含：

| 位置 | 内容 |
|---|---|
| teamflow/plan.json | 工作包、写入范围、依赖、验收 ID、估时 |
| teamflow/schedule.json | 建议负责人、预计开始/结束时间 |
| teamflow/source-context.json | 输入来源哈希、选取的文本和行号 |
| openspec/schemas/team-parallel/ | 自定义六阶段 schema 和模板 |
| openspec/changes/变更ID/ | proposal、specs、design、contracts、tasks、handoff |

估时只用于调度排序，不能充当实测工期。调度启发式优先关键路径，再考虑可用成员、技能、写路径/共享资源冲突与负载，不保证全局最优。

负责人核对需求语义、契约一致性、目录权限和拆分粒度。现有工程的当前接口/spec 必须纳入设计输入；本版本不自动遍历整个代码仓库，也不自动迁移既有 OpenSpec 主规格。审核后从 `result.json` 复制 `bundle_sha256`：

```bash
teamflow install --bundle ../runs/plan-001 \
  --project ../my-project --approve 审核后的bundle_sha256
```

安装先检查冲突；存在不同内容的目标文件时拒绝复制。已有 OpenSpec 配置与 `.gitignore` 保留，变更自身的 `.openspec.yaml` 显式选择 `team-parallel`。如目标不是 Git 仓库，先 `git init`。确保 `.gitignore` 包含 `.teamflow/`，审核后提交规划快照；创建 worktree 要求工作区干净。

## 4. 多人并行开发

负责人为每个变更准备测试配置，放在 worktree 之外，例如 `../checks/foundation-contracts.json`：

```json
{
  "checks": [
    {
      "id": "AC01",
      "argv": ["python", "-m", "pytest", "tests/test_contract.py"],
      "timeout_seconds": 60
    }
  ]
}
```

测试程序和依赖应已安装并存在于提交的基线中，或使用受控的外部测试路径。示例的 pytest 是你的项目测试依赖，不是 TeamFlow 运行依赖。`{python}` 可以引用运行 TeamFlow 的 Python。每个任务的验收 ID 必须有对应检查；程序验证 ID 覆盖，但不能保证检查语义足够强。测试配置由负责人提供，LLM 不能修改它；模型写入范围不应包含可信验收测试。执行采用 argv 和 `shell=False`，不执行模型生成的 shell 命令。

准备齐可执行变更的检查配置后，在中央执行主机启动一波：

```bash
teamflow batch --llm config/llm.local.json \
  --project ../my-project --checks-dir ../checks \
  --worktrees ../worktrees --out ../runs/wave-001 \
  --execute-checks
```

工作包按建议负责人选择，成员并发容量为 1，总并发不超过 N；仅领取依赖已集成且写范围无冲突的任务。缺少检查配置或依赖未满足会列入 skipped。首波可能只有公共契约任务，这符合依赖约束。`batch` 是一波执行，不会自行审批、合并后继续下一波。检查各 Worker 的 `READY_FOR_REVIEW/BLOCKED`，审核并集成后再次运行新的输出目录。

多个成员也可分别在同一协调主机使用单任务命令：

```bash
teamflow claim --project ../my-project \
  --change foundation-contracts --member D1
teamflow workspace --project ../my-project \
  --change foundation-contracts --token 领取结果中的token \
  --destination ../worktrees/foundation
teamflow packet --project ../my-project \
  --change foundation-contracts --token 领取结果中的token
teamflow develop --llm config/llm.local.json \
  --project ../my-project --change foundation-contracts \
  --token 领取结果中的token --checks ../checks/foundation-contracts.json \
  --out ../runs/dev-001 --execute-checks
```

代码生成每轮最多 30 个文件、单文件 200 KB、总量 1 MB；使用完整 UTF-8 文件内容，不支持删除或二进制修改。只写计划中的路径前缀，拒绝路径穿越、符号链接、隐藏文件以及 OpenSpec/teamflow/CI 元数据等受保护路径。失败时保留工作区和日志供检查，不自动覆盖用户修改；再次开发要求干净的领取基线。调整或重启任务前先停止旧 Worker，保留改动，再 release 并重新领取；不要把失败状态当成已集成。

成功也只进入 `READY_FOR_REVIEW`，不自动勾选任务、不自动提交/推送/合并/归档。集成负责人审核、运行 CI、把实现提交合并到中央仓库后，准备 receipt：

```json
{
  "change_id": "foundation-contracts",
  "plan_sha256": "领取结果中的plan_sha256",
  "commit": "已合并实现的完整commit哈希",
  "ci_run_url": "https://你的CI/真实运行地址",
  "reviewer": "D2",
  "passed": true,
  "passed_acceptance_ids": ["AC01"]
}
```

`bundle_sha256` 审批安装包，`plan_sha256` 绑定已安装的规划快照；两者用途和计算范围不同，不可互换。

```bash
teamflow record-integrated --project ../my-project \
  --change foundation-contracts --token 领取结果中的token \
  --receipt ../receipts/foundation-contracts.json
teamflow status --project ../my-project
```

程序检查提交祖先关系、验收 ID、独立 reviewer 和快照匹配。**CI URL/人工结论是操作员声明，当前未对接 CI 身份验证。** 负责人确认后才解锁下游。正式归档由集成负责人按 OpenSpec 工作流操作，活动任务期间不要改写规划快照。多人跨机器生产部署需要中央协调服务/授权与 CI 集成，本版本的 SQLite、token 和文件锁只用于单主机受信环境协作。

## 5. 证据、预算和故障定位

```bash
python scripts/verify.py
```

`evidence/protocol.json` 在本次首次执行前登记 G01–G06 目标；`test-results.json` 记录实际测试用例、日期、耗时及协议哈希；`demo/` 保存一次真实执行的演示日志和结果。复制包里的记录是本次验证快照，再运行会更新测试结果。

- `events.jsonl`：真实 HTTP 尝试、服务报告用量、校验失败、测试退出码。
- `responses/`：模型最终返回；`checks/`：实际测试输出；`result.json`：阶段结果。
- `max_http_calls` 限制单个运行/Worker 的请求总数，包含网络重试；batch 预算为各 Worker 预算之和。
- `max_reported_tokens` 仅在下一请求前检查服务返回的 token 累计。一次调用可超出阈值；服务不提供 usage 时不能硬性限制 token/费用。报告 `usage_incomplete`，不估造 token 或账单。
- 规划/代码语义反馈轮次与 HTTP 重试分别计数。输出截断、连接最终失败等需要调整配置后使用新输出目录重新运行。本版不支持断点续传。
- `BLOCKED`：查最近一次 check 日志；`fingerprint changed`：先协调设计变更；`worker ... lock`：确认进程已停止后人工清理对应锁；`dependencies not integrated`：先完成真实审核与 receipt。

Git worktree 隔离变更，不是 OS 沙箱。批准的测试仍可能执行生成代码。生产使用应在容器/受限账号中运行，限制网络和磁盘；当前 subprocess 超时与输出截取不是完整资源隔离。Linux 超时会终止测试进程组，Windows 仅终止父进程。不要在含生产凭据的环境直接执行未审查的代码。

## 6. 真实团队试点

本次没有用户模型地址与权限，也没有真实成员操作数据。因此本地模型兼容性需先跑 doctor + 一条真实需求验证，真实团队价值仍待试点。

建议对 8 个相似业务包做 4 对配对比较：A 组为 OpenSpec + 人工拆分 + 同一编码模型，B 组增加 TeamFlow；保持模型、人员、验收范围一致。预先锁定目标：规划耗时下降 ≥50%，交付周期下降 ≥20%，验收通过率 100%，7 天严重新增缺陷为 0，成本比 ≤1.2。记录需求冻结/计划审批/领取/测试/合并时间、人工分钟、服务用量和缺陷。中途失败也纳入统计，标记需求变更和阻塞时间。详见 `examples/ticketing/pilot_protocol.json` 与 `field_event.schema.json`。这些目标尚未达成验证，不得将估时或 mock 用量替代团队数据。

## 7. 源码和许可

主要模块：`llm.py`（HTTP），`context.py`（设计索引），`workflow.py`（规划/产物循环），`planning.py`（约束与调度），`coordinator.py`（SQLite/领取/交接），`developer.py`（编辑测试循环），`batch.py`（按成员并发），`openspec.py`（原生 CLI），`mock_server.py`/`demo.py`（明确标识的测试替身）。

`LICENSE` 为本项目 MIT 许可；`THIRD_PARTY_NOTICES.md` 和 `licenses/` 说明 OpenSpec 第三方许可。包不包含模型权重、API 密钥、node_modules 或虚拟环境。`dist/` 提供已检查资源完整性的 wheel。所有公开发布前应复核业务数据与许可证，公开仓库地址由项目维护者建立后填写。

资料：[OpenSpec](https://github.com/Fission-AI/OpenSpec) · [OpenSpec 自定义 schema](https://github.com/Fission-AI/OpenSpec/blob/main/docs/customization.md) · [Ollama OpenAI compatibility](https://docs.ollama.com/api/openai-compatibility) · [vLLM serving](https://docs.vllm.ai/en/latest/serving/online_serving/)
