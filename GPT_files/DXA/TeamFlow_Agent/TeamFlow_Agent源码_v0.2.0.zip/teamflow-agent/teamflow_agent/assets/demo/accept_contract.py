"""Five demo assertions exercising actual generated Python code. Not full business acceptance."""
import importlib.util
from pathlib import Path

p = Path.cwd() / "contracts/ticket-v1/validator.py"
spec = importlib.util.spec_from_file_location("demo_contract",p)
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
valid = {"id":"T-1","title":"Demo","status":"open","actor_id":"U-1","tenant_id":"TEN-1","idempotency_key":"K-1"}
assert module.validate_ticket(valid)["ok"] is True, "valid example must pass"
missing = dict(valid)
del missing["tenant_id"]
assert module.validate_ticket(missing)["ok"] is False, "missing tenant must fail"
assert module.validate_ticket(missing)["error"] == "INVALID_INPUT", "stable invalid-input code required"
assert module.validate_ticket({**valid,"status":"invalid"})["ok"] is False, "invalid status must fail"
assert module.validate_ticket(None)["ok"] is False, "non-object must fail"
print("5 demo contract assertions passed; full business acceptance is still pending")
