# 集成接线与回归设计
## Source
teamflow/source-design.md，R06 节；需求登记 teamflow/requirements.json。
## Decisions
依赖：ticket-api, ticket-ui, audit-events, test-harness。以 ticket-v1 作为接口边界；前端和测试设施使用冻结契约的 mock，并不等待后端实现。
## Non-goals
不修改其他工作包、生产部署配置或当前 openspec/specs；不把示例工时当成实测。
## Risks
接口变化必须由集成负责人发起重新规划；声明的路径不提供操作系统权限隔离。
