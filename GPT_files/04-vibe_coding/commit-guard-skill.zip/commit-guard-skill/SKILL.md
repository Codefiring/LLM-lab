---
name: commit-guard
description: Enforce company commit rules before creating Git commits. Use this skill whenever the user asks to commit code, prepare a commit, generate a commit message, split changes into commits, or run git commit. It checks staged diff size, blocks commits over 500 changed lines, guides safe commit splitting, and standardizes commit messages.
---

# Commit Guard Skill

## Purpose

Use this skill whenever you are about to help with a Git commit in an AI coding workflow.

Company rule: **each commit must not exceed 500 changed lines**.

Changed lines means:

- Added lines + deleted lines in the staged diff.
- Do not count diff metadata, file headers, or context lines.
- Binary files cannot be counted reliably and must be flagged for human review.

The goal is to ensure every commit is small, reviewable, logically coherent, and compliant.

## When to activate

Activate this skill when the user asks to:

- commit code
- generate a commit message
- prepare a PR commit series
- split changes into commits
- run `git add`, `git commit`, or equivalent
- review staged changes before committing
- use an AI coding tool to make or commit code changes

## Mandatory workflow

Before creating or recommending any commit, do the following:

1. Inspect the repository status.
2. Inspect staged changes.
3. Count staged changed lines.
4. If staged changed lines are `<= 500`, allow the commit.
5. If staged changed lines are `> 500`, do **not** commit. Split the changes into multiple logical commits.
6. After splitting, re-check each proposed commit.
7. Generate a commit message only after the commit is compliant.

Never run `git commit` before the 500-line check passes.

## Preferred command

Run the bundled checker from the repository root:

```bash
python .claude/skills/commit-guard/scripts/commit_guard.py --limit 500
```

If the skill is installed globally, use the actual path to the script.

## Manual fallback commands

If the script is unavailable, use:

```bash
git diff --cached --numstat
```

Then calculate:

```text
changed_lines = sum(added + deleted for each non-binary file)
```

Binary files appear as `-` in `git diff --cached --numstat`; report them separately.

## Decision rules

### Pass

If staged changed lines are less than or equal to 500:

- Summarize changed files.
- Generate a concise commit message.
- Ask for confirmation before committing unless the user explicitly asked to commit now.

### Fail

If staged changed lines exceed 500:

- Do not commit.
- Explain the current staged line count.
- Propose a split plan based on logical functionality, not arbitrary file chunks.
- Unstage all or part of the changes as needed.
- Stage and commit one logical group at a time.
- Re-run the checker before every commit.

## Splitting strategy

Split by intent in this order:

1. Infrastructure/config changes.
2. Data model/schema changes.
3. Core implementation changes.
4. API/interface changes.
5. UI changes.
6. Tests.
7. Documentation.
8. Refactor-only changes.
9. Formatting-only changes.

Prefer commits that can be reviewed independently and, ideally, build independently.

Avoid commits like:

- `misc changes`
- `fix stuff`
- `update files`
- mechanically splitting a single feature into meaningless 500-line chunks

## Safe staging commands

Use file-level staging for clearly separated files:

```bash
git add path/to/file1 path/to/file2
```

Use patch staging when one file contains multiple logical changes:

```bash
git add -p path/to/file
```

Use restore to unstage when needed:

```bash
git restore --staged .
```

or:

```bash
git restore --staged path/to/file
```

## Commit message standard

Use Conventional Commit style unless the repository clearly uses another convention:

```text
<type>(optional-scope): <summary>
```

Allowed common types:

- `feat`
- `fix`
- `refactor`
- `test`
- `docs`
- `chore`
- `build`
- `ci`
- `perf`

Examples:

```text
feat(auth): add OAuth token refresh flow
fix(api): validate empty tool response payloads
test(scanner): add path traversal regression cases
```

## Required output before committing

Before each commit, show:

```text
Commit Guard Check
- Staged changed lines: <number> / 500
- Binary files: <none or list>
- Files included: <list>
- Decision: PASS or BLOCKED
- Proposed commit message: <message>
```

## Hard constraints

- Do not bypass the limit with `--no-verify` unless the user explicitly instructs it and acknowledges policy violation.
- Do not include generated lockfiles, build artifacts, snapshots, or vendored files in the same commit as source changes unless necessary.
- Do not mix formatting-only changes with functional changes.
- Do not commit secrets, tokens, `.env`, private keys, or credential files.
- If the staged diff includes secrets, stop and warn the user.

## Recommended pre-commit behavior

If possible, also run the relevant lightweight checks before committing:

```bash
git diff --cached --check
```

Then run project-specific tests only if they are obvious and cheap, for example:

```bash
npm test
pytest
cargo test
go test ./...
```

Do not invent test commands. Inspect the project first.
