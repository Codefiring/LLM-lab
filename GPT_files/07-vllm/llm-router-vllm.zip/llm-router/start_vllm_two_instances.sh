#!/usr/bin/env bash
set -euo pipefail

MODEL="${MODEL:-/path/to/your/model}"
SERVED_MODEL_NAME="${SERVED_MODEL_NAME:-your-model-name}"

# A100 8卡：两个 TP=4 实例
# 实例 A: GPU 0-3
CUDA_VISIBLE_DEVICES=0,1,2,3 \
vllm serve "$MODEL" \
  --served-model-name "$SERVED_MODEL_NAME" \
  --tensor-parallel-size 4 \
  --host 0.0.0.0 \
  --port 8001 \
  --gpu-memory-utilization 0.90 \
  --api-key vllm-token-a &

# 实例 B: GPU 4-7
CUDA_VISIBLE_DEVICES=4,5,6,7 \
vllm serve "$MODEL" \
  --served-model-name "$SERVED_MODEL_NAME" \
  --tensor-parallel-size 4 \
  --host 0.0.0.0 \
  --port 8002 \
  --gpu-memory-utilization 0.90 \
  --api-key vllm-token-b &

wait