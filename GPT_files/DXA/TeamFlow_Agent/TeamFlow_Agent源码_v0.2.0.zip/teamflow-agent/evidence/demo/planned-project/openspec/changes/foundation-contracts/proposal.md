# 共享工单契约
## Why
实现示例工单变更的一项独立可验收工作，降低多人并行时的交接成本。
## What Changes
- 共享工单契约，对应 R01 / AC01。
## Capabilities
### New Capabilities
- ticket-contract: 共享工单契约
### Modified Capabilities
- 无。
## Impact
写入范围：contracts/ticket-v1/。本文件是待开发示例，不是完成证明。
