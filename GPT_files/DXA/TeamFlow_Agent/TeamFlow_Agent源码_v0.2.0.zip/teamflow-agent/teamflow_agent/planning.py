#!/usr/bin/env python3
"""Structural checks and critical-path-priority scheduling."""
from __future__ import annotations

import json
import math
from pathlib import Path, PurePosixPath
import re


def read_json(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))


def write_json(path, value):
    Path(path).write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def path_overlap(a, b):
    a, b = a.rstrip("/"), b.rstrip("/")
    return a == b or a.startswith(b + "/") or b.startswith(a + "/")


def conflicts(a, b):
    return bool(set(a.get("shared_resources", [])) & set(b.get("shared_resources", []))) or any(
        path_overlap(x, y) for x in a["paths_write"] for y in b["paths_write"]
    )


def validate(plan, manifest, team):
    """Reject structural defects. Semantic correctness still needs human review."""
    if not isinstance(plan, dict) or not isinstance(plan.get("tasks"), list) or not plan["tasks"]:
        raise ValueError("plan.tasks must be a nonempty array")
    tasks = plan["tasks"]
    members = team.get("members", [])
    if not members or len({m["id"] for m in members}) != len(members):
        raise ValueError("team must contain nonempty, unique member IDs")
    if any(not isinstance(m.get("skills"), list) for m in members):
        raise ValueError("member skills must be an array")
    reqs = {r["id"]: r for r in manifest["requirements"]}
    if not reqs:
        raise ValueError("authoritative requirements cannot be empty")
    known_tests = {x for r in reqs.values() for x in r["acceptance_tests"]}
    ids = [t.get("id") for t in tasks]
    if any(not isinstance(i, str) or not re.fullmatch(r"[A-Za-z0-9_-]+", i) for i in ids):
        raise ValueError("task IDs must be safe, nonempty identifiers")
    if len(set(ids)) != len(ids):
        raise ValueError("duplicate task IDs")
    by_id = dict(zip(ids, tasks))
    for t in tasks:
        for field in ("requirements", "depends_on", "required_skills", "paths_write", "acceptance_tests"):
            if not isinstance(t.get(field), list) or any(not isinstance(x, str) for x in t[field]):
                raise ValueError(f"{t['id']}: {field} must be an array of strings")
        if not all(t[f] for f in ("requirements", "paths_write", "acceptance_tests")):
            raise ValueError(f"{t['id']}: missing requirement, write scope or acceptance test")
        if not isinstance(t.get("title"), str) or not t["title"].strip():
            raise ValueError(f"{t['id']}: title required")
        if not isinstance(t.get("contract_version"), str) or not t["contract_version"]:
            raise ValueError(f"{t['id']}: contract version required")
        resources = t.get("shared_resources", [])
        if not isinstance(resources, list) or any(not isinstance(x, str) for x in resources):
            raise ValueError(f"{t['id']}: invalid shared resources")
        h = t.get("estimate_hours")
        if isinstance(h, bool) or not isinstance(h, (int, float)) or not math.isfinite(h) or not 0 < h <= 16:
            raise ValueError(f"{t['id']}: estimate must be finite and in (0,16] hours")
        if set(t["requirements"]) - reqs.keys():
            raise ValueError(f"{t['id']}: unknown requirement")
        if set(t["acceptance_tests"]) - known_tests:
            raise ValueError(f"{t['id']}: unknown acceptance test")
        if set(t["depends_on"]) - by_id.keys() or t["id"] in t["depends_on"]:
            raise ValueError(f"{t['id']}: unknown dependency or self dependency")
        for p in t["paths_write"]:
            q = PurePosixPath(p)
            if not p or p in (".", "/") or q.is_absolute() or ".." in q.parts or "\\" in p or ":" in p or any(x in p for x in "*?["):
                raise ValueError(f"{t['id']}: invalid repository-relative path {p!r}")
        if not any(set(t["required_skills"]) <= set(m["skills"]) for m in members):
            raise ValueError(f"{t['id']}: no eligible team member")
    for rid, req in reqs.items():
        owners = [t for t in tasks if rid in t["requirements"]]
        if not owners:
            raise ValueError(f"uncovered requirement {rid}")
        covered = {a for t in owners for a in t["acceptance_tests"]}
        if not set(req["acceptance_tests"]) <= covered:
            raise ValueError(f"uncovered acceptance tests for {rid}")
    order, remaining = [], set(ids)
    while remaining:
        ready = sorted(i for i in remaining if set(by_id[i]["depends_on"]) <= set(order))
        if not ready:
            raise ValueError("dependency cycle")
        order.extend(ready)
        remaining.difference_update(ready)
    return order


def schedule(plan, manifest, team):
    order = validate(plan, manifest, team)
    tasks = {t["id"]: t for t in plan["tasks"]}
    successors = {i: [] for i in tasks}
    for t in tasks.values():
        for d in t["depends_on"]:
            successors[d].append(t["id"])
    tail = {}
    for i in reversed(order):
        tail[i] = tasks[i]["estimate_hours"] + max((tail[j] for j in successors[i]), default=0)
    placed, rows = {}, []
    remaining = set(order)
    while remaining:
        ready = [i for i in remaining if set(tasks[i]["depends_on"]) <= placed.keys()]
        tid = min(ready, key=lambda i: (-tail[i], i))
        task = tasks[tid]
        earliest = max((placed[d]["end_hour"] for d in task["depends_on"]), default=0)
        options = []
        for member in team["members"]:
            if not set(task["required_skills"]) <= set(member["skills"]):
                continue
            start = earliest
            while True:
                end = start + task["estimate_hours"]
                blockers = [r for r in rows if start < r["end_hour"] and r["start_hour"] < end and
                            (r["owner"] == member["id"] or conflicts(task, tasks[r["task_id"]]))]
                if not blockers:
                    break
                start = max(r["end_hour"] for r in blockers)
            load = sum(r["end_hour"] - r["start_hour"] for r in rows if r["owner"] == member["id"])
            options.append((end, load, member["id"], start))
        end, _, owner, start = min(options)
        row = {"task_id": tid, "owner": owner, "start_hour": start, "end_hour": end,
               "title": task["title"], "critical_tail_hours": tail[tid]}
        rows.append(row)
        placed[tid] = row
        remaining.remove(tid)
    makespan = max(r["end_hour"] for r in rows)
    total = sum(t["estimate_hours"] for t in tasks.values())
    return {"evidence_type": "ESTIMATE_NOT_OBSERVED_DEVELOPMENT", "team_size": len(team["members"]),
            "task_count": len(tasks), "estimated_total_person_hours": total,
            "estimated_makespan_hours": makespan,
            "optimistic_lower_bound_hours": max(max(tail.values()), total / len(team["members"])),
            "estimated_capacity_use": total / (len(team["members"]) * makespan),
            "assignments": sorted(rows, key=lambda r: (r["start_hour"], r["owner"], r["task_id"]))}

