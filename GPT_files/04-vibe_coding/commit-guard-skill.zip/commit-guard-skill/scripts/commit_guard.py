#!/usr/bin/env python3
"""
Commit Guard: enforce a maximum staged diff size before git commit.

Default rule: added lines + deleted lines in staged diff must be <= 500.
"""

from __future__ import annotations

import argparse
import subprocess
import sys
from dataclasses import dataclass
from typing import List


@dataclass
class FileStat:
    added: int | None
    deleted: int | None
    path: str

    @property
    def is_binary(self) -> bool:
        return self.added is None or self.deleted is None

    @property
    def changed(self) -> int:
        if self.is_binary:
            return 0
        return int(self.added or 0) + int(self.deleted or 0)


def run_git(args: List[str]) -> str:
    try:
        result = subprocess.run(
            ["git", *args],
            check=True,
            text=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
        )
        return result.stdout
    except subprocess.CalledProcessError as exc:
        print(exc.stderr.strip() or str(exc), file=sys.stderr)
        sys.exit(2)


def parse_numstat(output: str) -> List[FileStat]:
    stats: List[FileStat] = []
    for line in output.splitlines():
        if not line.strip():
            continue
        parts = line.split("\t")
        if len(parts) < 3:
            continue
        added_s, deleted_s, path = parts[0], parts[1], "\t".join(parts[2:])
        if added_s == "-" or deleted_s == "-":
            stats.append(FileStat(None, None, path))
        else:
            stats.append(FileStat(int(added_s), int(deleted_s), path))
    return stats


def main() -> int:
    parser = argparse.ArgumentParser(description="Check staged Git diff size before commit.")
    parser.add_argument("--limit", type=int, default=500, help="Maximum allowed changed lines. Default: 500")
    parser.add_argument("--json", action="store_true", help="Output machine-readable JSON")
    args = parser.parse_args()

    # Ensure we are in a git repository.
    run_git(["rev-parse", "--show-toplevel"])

    numstat = run_git(["diff", "--cached", "--numstat"])
    stats = parse_numstat(numstat)

    total = sum(s.changed for s in stats)
    binary_files = [s.path for s in stats if s.is_binary]
    files = [s.path for s in stats]
    passed = total <= args.limit and len(files) > 0

    if args.json:
        import json

        print(json.dumps({
            "limit": args.limit,
            "staged_changed_lines": total,
            "binary_files": binary_files,
            "files": files,
            "passed": passed,
            "has_staged_changes": len(files) > 0,
        }, ensure_ascii=False, indent=2))
    else:
        print("Commit Guard Check")
        print(f"- Staged changed lines: {total} / {args.limit}")
        print(f"- Binary files: {', '.join(binary_files) if binary_files else 'none'}")
        print("- Files included:")
        if files:
            for s in stats:
                suffix = "binary" if s.is_binary else f"+{s.added} -{s.deleted}"
                print(f"  - {s.path} ({suffix})")
        else:
            print("  - none")
        if not files:
            print("- Decision: BLOCKED — no staged changes")
        elif total > args.limit:
            print("- Decision: BLOCKED — staged diff exceeds line limit")
            print("- Suggested action: unstage changes and split into smaller logical commits")
        else:
            print("- Decision: PASS")

    if not files:
        return 1
    return 0 if total <= args.limit else 1


if __name__ == "__main__":
    raise SystemExit(main())
