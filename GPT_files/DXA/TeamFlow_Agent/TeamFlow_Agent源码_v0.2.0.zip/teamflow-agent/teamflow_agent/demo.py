from __future__ import annotations
import datetime as dt
from pathlib import Path
import platform
import time
from .common import read_json, write_json, git, Trace
from .coordinator import Coordinator
from .developer import develop_run
from .llm import Client
from .workflow import plan_run, install_bundle
from .mock_server import serve, DEMO


def run_demo(out):
    root = Path(out).resolve()
    root.mkdir(parents=True,exist_ok=False)
    start = time.monotonic()
    with serve() as (settings,captured,responder):
        doctor = Client(settings,Trace(root/"doctor")).doctor()
        plan = plan_run(settings,DEMO/"source-design.md",read_json(DEMO/"requirements.json"),
                        read_json(DEMO/"members.json"),root/"planning")
        project = root/"project"
        install_bundle(root/"planning",project,plan["bundle_sha256"])
        git(project,"init","--initial-branch=main")
        git(project,"add",".")
        git(project,"-c","user.name=TeamFlow Demo","-c","user.email=demo@example.invalid",
            "commit","-m","Reviewed fixture planning snapshot for mechanism test")
        c = Coordinator(project)
        claim = c.claim("foundation-contracts","D1")
        workspace = c.workspace("foundation-contracts",claim["token"],root/"worktrees/foundation")
        checks = {"checks":[{"id":"AC01","argv":["{python}",str(DEMO/"accept_contract.py")],"timeout_seconds":20}]}
        write_json(root/"checks.json",checks)
        dev = develop_run(settings,project,"foundation-contracts",claim["token"],root/"checks.json",
                          root/"development",execute_checks=True)
        # Request bodies and Authorization headers are deliberately not exported.
        result = {"evidence_type":"REAL_EXECUTION_WITH_DETERMINISTIC_HTTP_TEST_DOUBLE",
                  "run_at_utc":dt.datetime.now(dt.timezone.utc).isoformat(),"python":platform.python_version(),
                  "platform":platform.platform(),"real_model_inference_calls":0,"human_pilot_participants":0,
                  "http_requests_observed":len(captured),"stage_request_counts":responder.counts,
                  "native_openspec_changes_validated":plan["changes_validated"],
                  "planning":plan["schedule"],"development_rounds":dev["attempts"],
                  "development_final_state":dev["state"],"contract_demo_assertions":5,
                  "worktree_created":Path(workspace["path"]).is_dir(),
                  "delivery_complete":False,"runtime_seconds":round(time.monotonic()-start,3),
                  "scope":"One demo contract task only; other five tasks and full business acceptance are not implemented."}
        write_json(root/"demo-result.json",result)
        return result
