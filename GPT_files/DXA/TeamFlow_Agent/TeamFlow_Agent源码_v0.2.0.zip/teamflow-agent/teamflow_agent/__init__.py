"""TeamFlow local-model agents."""
__version__ = "0.2.0"
