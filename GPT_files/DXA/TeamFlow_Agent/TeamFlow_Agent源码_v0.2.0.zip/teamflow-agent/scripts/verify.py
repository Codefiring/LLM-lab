"""Record actual automated test outcomes against the predeclared protocol."""
import datetime as dt
import hashlib
import json
from pathlib import Path
import platform
import sys
import time
import unittest

root = Path(__file__).resolve().parents[1]
sys.path.insert(0,str(root))
start = time.monotonic()
protocol = root/"evidence/protocol.json"
suite = unittest.defaultTestLoader.discover(str(root/"tests"))
class RecordingResult(unittest.TextTestResult):
    cases = []
    def addSuccess(self,test):
        super().addSuccess(test)
        self.cases.append({"case":test.id(),"outcome":"passed"})
    def addFailure(self,test,err):
        super().addFailure(test,err)
        self.cases.append({"case":test.id(),"outcome":"failed"})
    def addError(self,test,err):
        super().addError(test,err)
        self.cases.append({"case":test.id(),"outcome":"error"})
    def addSkip(self,test,reason):
        super().addSkip(test,reason)
        self.cases.append({"case":test.id(),"outcome":"skipped","reason":reason})

result = unittest.TextTestRunner(verbosity=2,resultclass=RecordingResult).run(suite)
summary = {"evidence_type":"REAL_AUTOMATED_MECHANISM_TESTS_WITH_HTTP_TEST_DOUBLE",
           "run_at_utc":dt.datetime.now(dt.timezone.utc).isoformat(),"python":platform.python_version(),
           "platform":platform.platform(),"protocol_sha256":hashlib.sha256(protocol.read_bytes()).hexdigest(),
           "tests_run":result.testsRun,"failures":len(result.failures),"errors":len(result.errors),
           "skipped":len(result.skipped),"passed":result.wasSuccessful(),"cases":result.cases,
           "duration_seconds":round(time.monotonic()-start,3),"real_model_inference_calls":0,
           "human_pilot_participants":0}
(root/"evidence/test-results.json").write_text(json.dumps(summary,ensure_ascii=False,indent=2)+"\n")
raise SystemExit(0 if result.wasSuccessful() else 1)
