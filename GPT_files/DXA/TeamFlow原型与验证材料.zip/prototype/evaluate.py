"""Predefined local mechanism checks; all fixture data is artificial."""
import copy
import datetime as dt
import hashlib
import json
from pathlib import Path
import platform
import sys
import time

from teamflow import read_json, schedule, validate, plan_agent, save_outputs, write_json

ROOT = Path(__file__).parent
PLAN = read_json(ROOT/'examples/plan.json')
REQ = read_json(ROOT/'examples/requirements.json')
TEAM = read_json(ROOT/'examples/team.json')
checks = []


def independent_oracle(result, plan, team):
    rows = result['assignments']
    tasks = {t['id']:t for t in plan['tasks']}
    members = {m['id']:m for m in team['members']}
    index = {r['task_id']:r for r in rows}
    assert len(rows) == len(tasks) == len(index)
    for r in rows:
        task = tasks[r['task_id']]
        assert r['owner'] in members
        assert set(task['required_skills']) <= set(members[r['owner']]['skills'])
        assert r['end_hour']-r['start_hour'] == task['estimate_hours']
        assert r['start_hour'] >= 0
        assert all(index[d]['end_hour'] <= r['start_hour'] for d in task['depends_on'])
    boundaries = sorted({r[k] for r in rows for k in ['start_hour','end_hour']})
    for left, right in zip(boundaries, boundaries[1:]):
        midpoint = (left + right)/2
        active = [r for r in rows if r['start_hour'] <= midpoint < r['end_hour']]
        assert len(active) <= len(members)
        assert len({r['owner'] for r in active}) == len(active)
        for i, a in enumerate(active):
            for b in active[i+1:]:
                ta, tb = tasks[a['task_id']], tasks[b['task_id']]
                assert not (set(ta.get('shared_resources',[])) & set(tb.get('shared_resources',[])))
                for pa in ta['paths_write']:
                    for pb in tb['paths_write']:
                        aa, bb = pa.rstrip('/').split('/'), pb.rstrip('/').split('/')
                        assert aa[:min(len(aa),len(bb))] != bb[:min(len(aa),len(bb))]


def rejected(name, mutate):
    p, r, t = copy.deepcopy(PLAN), copy.deepcopy(REQ), copy.deepcopy(TEAM)
    mutate(p, r, t)
    try:
        validate(p, r, t)
    except (ValueError, TypeError, KeyError) as exc:
        checks.append({'name':name, 'passed':True, 'reason':str(exc)})
    else:
        checks.append({'name':name, 'passed':False, 'reason':'invalid input was accepted'})


def main():
    out = Path(sys.argv[1]) if len(sys.argv)>1 else ROOT/'evidence'/'local-verification'
    out.mkdir(parents=True, exist_ok=False)
    start = time.perf_counter()
    protocol = ROOT/'evaluation_protocol.json'
    protocol_sha = hashlib.sha256(protocol.read_bytes()).hexdigest()
    # The complete list is defined before any checks execute.
    invalid = [
        ('duplicate_task', lambda p,r,t: p['tasks'].append(copy.deepcopy(p['tasks'][0]))),
        ('missing_dependency', lambda p,r,t: p['tasks'][0].update(depends_on=['X'])),
        ('cycle', lambda p,r,t: p['tasks'][0].update(depends_on=['T16'])),
        ('negative_estimate', lambda p,r,t: p['tasks'][0].update(estimate_hours=-1)),
        ('oversized_task', lambda p,r,t: p['tasks'][0].update(estimate_hours=100)),
        ('nan_estimate', lambda p,r,t: p['tasks'][0].update(estimate_hours=float('nan'))),
        ('uncovered_requirement', lambda p,r,t: r['requirements'].append({'id':'R99','acceptance_tests':['AC99']})),
        ('unknown_acceptance', lambda p,r,t: p['tasks'][0].update(acceptance_tests=['AC99'])),
        ('ineligible_team', lambda p,r,t: p['tasks'][0].update(required_skills=['nonexistent_skill'])),
        ('path_escape', lambda p,r,t: p['tasks'][0].update(paths_write=['../outside'])),
        ('empty_team', lambda p,r,t: t.update(members=[])),
        ('empty_acceptance', lambda p,r,t: p['tasks'][0].update(acceptance_tests=[]))
    ]
    for name, mutate in invalid:
        rejected(name, mutate)
    cases = []
    for n in [2,4,6]:
        skills = sorted({s for task in PLAN['tasks'] for s in task['required_skills']})
        team = {'members':[{'id':f'D{i+1}','skills':skills} for i in range(n)]}
        cases.append((f'homogeneous_{n}_members', PLAN, team))
    locked_plan = copy.deepcopy(PLAN)
    locked_plan['tasks'][4]['paths_write'] = ['src/shared/']
    locked_plan['tasks'][5]['paths_write'] = ['src/shared/handler.py']
    locked_plan['tasks'][10]['shared_resources'] = ['service-config']
    locked_plan['tasks'][11]['shared_resources'] = ['service-config']
    cases.append(('heterogeneous_with_resource_and_prefix_conflicts', locked_plan, TEAM))
    summaries = []
    for name, plan, team in cases:
        before = time.perf_counter()
        result = schedule(plan, REQ, team)
        elapsed = (time.perf_counter()-before)*1000
        try:
            independent_oracle(result, plan, team)
            checks.append({'name':name, 'passed':True})
        except AssertionError:
            checks.append({'name':name, 'passed':False})
        write_json(out/f'{name}.json', result)
        summaries.append({'case':name, 'task_count':result['task_count'], 'people':result['team_size'],
                          'scheduler_wall_ms':round(elapsed,3),
                          'estimated_makespan_hours':result['estimated_makespan_hours'],
                          'schedule_time_is_estimate':True})
    repair = out/'fixture-repair'
    repair.mkdir()
    design = (ROOT/'examples/design.md').read_text(encoding='utf-8')
    plan, result = plan_agent(design, REQ, TEAM, [sys.executable,str(ROOT/'fixture_provider.py')], repair,
                              timeout=20, rounds=3, mode='FIXTURE_PROVIDER_NOT_LLM')
    save_outputs(repair, plan, result)
    events = [json.loads(line) for line in (repair/'events.jsonl').read_text(encoding='utf-8').splitlines()]
    checks.append({'name':'repair_feedback_loop', 'passed': any(e['event']=='candidate_rejected' for e in events)
                   and any(e['event']=='plan_validated' and e['attempt']==2 for e in events)})
    bounded = out/'fixture-bounded-failure'
    bounded.mkdir()
    try:
        plan_agent(design, REQ, TEAM, [sys.executable,str(ROOT/'fixture_provider.py')], bounded,
                   timeout=20, rounds=1, mode='FIXTURE_PROVIDER_NOT_LLM')
    except ValueError:
        checks.append({'name':'bounded_failure', 'passed':True})
    else:
        checks.append({'name':'bounded_failure', 'passed':False})
    result = {
        'evidence_type':'LOCAL_EXECUTION_ON_ARTIFICIAL_FIXTURES_NOT_TEAM_USAGE',
        'executed_at_utc':dt.datetime.now(dt.timezone.utc).isoformat(),
        'runtime':platform.python_version(), 'protocol_sha256':protocol_sha,
        'source_sha256':hashlib.sha256((ROOT/'teamflow.py').read_bytes()).hexdigest(),
        'passed':sum(c['passed'] for c in checks), 'total':len(checks),
        'checks':checks, 'schedule_cases':summaries,
        'total_wall_ms':round((time.perf_counter()-start)*1000,3),
        'real_team_participants':0, 'live_llm_calls':0,
        'productivity_improvement':None, 'field_goal_achieved':None
    }
    write_json(out/'verification.json', result)
    print(json.dumps(result,ensure_ascii=False,indent=2))
    return 0 if result['passed']==result['total'] else 1


if __name__ == '__main__':
    sys.exit(main())
