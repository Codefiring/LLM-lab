"""Deterministic test double. This is NOT an LLM or real usage evidence."""
import json
from pathlib import Path
import sys

prompt = sys.stdin.read()
plan = json.loads((Path(__file__).parent / 'examples/plan.json').read_text(encoding='utf-8'))
if prompt.rsplit('VALIDATOR FEEDBACK:\n', 1)[-1].strip() == '[]':
    plan['tasks'][0]['depends_on'] = ['NONEXISTENT_TASK']
print(json.dumps(plan, ensure_ascii=False))
