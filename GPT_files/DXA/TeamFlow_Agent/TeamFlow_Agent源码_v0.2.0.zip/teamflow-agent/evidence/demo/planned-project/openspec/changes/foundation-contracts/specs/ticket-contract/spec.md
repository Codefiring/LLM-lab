## Purpose
This capability defines observable ticketing behavior shared by the pilot team and provides a stable basis for independent implementation and acceptance.
## ADDED Requirements
### Requirement: 共享工单契约
The ticket contract SHALL define ticket ID, title, status, actor ID, tenant ID, error codes and idempotency semantics consistently for every consumer.
#### Scenario: AC01
- **WHEN** a consumer submits a malformed ticket payload
- **THEN** the contract validation identifies missing fields and defines a stable invalid-input error
