## Purpose
This capability defines observable ticketing behavior shared by the pilot team and provides a stable basis for independent implementation and acceptance.
## ADDED Requirements
### Requirement: 工单创建接口
The service SHALL create a tenant-isolated ticket and return the same ticket for a repeated idempotency key within the documented retention period.
#### Scenario: AC02
- **WHEN** an authorized user repeats a create request with the same idempotency key
- **THEN** only one ticket is created and cross-tenant access is rejected
