"""Bounded edit-test-feedback loop. A Git worktree is isolation of changes, not an OS sandbox."""
from __future__ import annotations
import os
from pathlib import Path
import signal
import subprocess
import sys
import time
from .common import TeamFlowError, Trace, atomic_write, read_json, write_json, parse_object, scoped_path, safe_relative, within, digest, git
from .coordinator import Coordinator
from .llm import Client
from .workflow import SYSTEM

PROTECTED = {".git", ".github", ".gitlab", ".teamflow", "openspec", "teamflow", "node_modules", ".venv"}


def editable(name, scopes):
    name = safe_relative(name)
    parts = name.split("/")
    if any(p.startswith(".") or p in PROTECTED for p in parts) or any(p.endswith((".pem", ".key")) for p in parts):
        raise TeamFlowError(f"protected path: {name}")
    if not any(within(name, scope) for scope in scopes):
        raise TeamFlowError(f"outside assigned write scope: {name}")
    return name


def apply_files(workspace, obj, scopes):
    files = obj.get("files")
    if not isinstance(files, list) or not 1 <= len(files) <= 30:
        raise TeamFlowError("files must contain 1..30 whole-text file edits")
    prepared = []
    seen = set()
    total = 0
    for item in files:
        name = editable(item["path"], scopes)
        p = scoped_path(workspace, name)
        if p.exists() and not p.is_file():
            raise TeamFlowError("cannot replace a directory")
        if name in seen:
            raise TeamFlowError("duplicate edited path")
        seen.add(name)
        content = item.get("content")
        if not isinstance(content, str) or "\x00" in content or len(content.encode()) > 200000:
            raise TeamFlowError("file content must be UTF-8 text under 200000 bytes")
        total += len(content.encode())
        if total > 1000000:
            raise TeamFlowError("edit batch exceeds 1 MB")
        parent = p.parent
        while parent != Path(workspace):
            if parent.exists() and not parent.is_dir():
                raise TeamFlowError("file blocks target directory")
            parent = parent.parent
        prepared.append((p, content))
    # All policy checks precede all writes. Restore prior content if an I/O failure occurs.
    backup = {p:p.read_text(encoding="utf-8") if p.exists() else None for p,_ in prepared}
    try:
        for p,content in prepared:
            atomic_write(p, content)
    except Exception:
        for p,before in backup.items():
            if before is None:
                p.unlink(missing_ok=True)
            else:
                atomic_write(p,before)
        raise
    return [p.relative_to(workspace).as_posix() for p,_ in prepared]


def context_files(workspace, task):
    root = Path(workspace)
    result = {}
    budget = 50000
    for prefix in task["paths_write"] + task.get("paths_read", []):
        p = scoped_path(root, prefix)
        paths = [p] if p.is_file() else sorted(p.rglob("*")) if p.is_dir() else []
        for f in paths:
            relative = f.relative_to(root).as_posix()
            if not f.is_file() or f.is_symlink() or any(x.startswith(".") or x in ("node_modules","__pycache__") for x in f.parts):
                continue
            scoped_path(root, relative)
            if f.stat().st_size > 200000:
                continue
            try:
                text = f.read_text(encoding="utf-8")
            except UnicodeError:
                continue
            if "\x00" in text:
                continue
            if len(text) > budget:
                return {"files":result, "truncated":True}
            budget -= len(text)
            result[relative] = text
    return {"files":result, "truncated":False}


def load_checks(path, acceptance, workspace):
    path = Path(path).resolve()
    if path.is_relative_to(workspace):
        raise TeamFlowError("checks configuration must be outside the writable worktree")
    obj = read_json(path)
    checks = obj.get("checks")
    if not isinstance(checks,list) or not checks or len(checks) > 30:
        raise TeamFlowError("checks must contain 1..30 operator-configured commands")
    ids = set()
    for c in checks:
        if not isinstance(c.get("id"),str) or c["id"] in ids:
            raise TeamFlowError("check IDs must be unique")
        safe_relative(c["id"])
        ids.add(c["id"])
        argv = c.get("argv")
        if not isinstance(argv,list) or not argv or any(not isinstance(x,str) or not x for x in argv):
            raise TeamFlowError("each check requires a nonempty argv array")
        timeout = c.get("timeout_seconds",60)
        if isinstance(timeout,bool) or not isinstance(timeout,(int,float)) or not 0 < timeout <= 600:
            raise TeamFlowError("check timeout must be in (0,600] seconds")
    if not set(acceptance) <= ids:
        raise TeamFlowError("check IDs must cover all acceptance_tests IDs for this change")
    return checks


def run_checks(checks, workspace, trace, attempt, key_env):
    results = []
    for c in checks:
        argv = [sys.executable if x == "{python}" else x for x in c["argv"]]
        log = trace.root / f"checks/round-{attempt}-{c['id'].replace('/','_')}.log"
        log.parent.mkdir(exist_ok=True)
        started = time.monotonic()
        env = dict(os.environ)
        if key_env:
            env.pop(key_env,None)
        env["PYTHONDONTWRITEBYTECODE"] = "1"
        timed_out = False
        with log.open("w",encoding="utf-8") as output:
            process = subprocess.Popen(argv,cwd=workspace,env=env,stdout=output,stderr=subprocess.STDOUT,
                                       text=True,shell=False,start_new_session=(os.name != "nt"))
            try:
                code = process.wait(timeout=c.get("timeout_seconds",60))
            except subprocess.TimeoutExpired:
                timed_out = True
                if os.name != "nt":
                    os.killpg(process.pid,signal.SIGKILL)
                else:
                    process.kill()
                code = process.wait()
        # Keep disk output bounded after completion, redact the configured LLM credential.
        with log.open("rb") as f:
            f.seek(max(0,log.stat().st_size - 16000))
            tail = f.read().decode("utf-8","replace")
        atomic_write(log,trace.redact(tail))
        row = {"id":c["id"],"returncode":code,"passed":code == 0 and not timed_out,
               "timed_out":timed_out,"duration_seconds":round(time.monotonic()-started,3),
               "log":log.relative_to(trace.root).as_posix(),"output_tail":tail[-6000:]}
        trace.emit("check_result",attempt=attempt,**row)
        results.append(row)
    return results


def assert_scope(workspace, base, scopes):
    tracked = git(workspace,"diff","--name-only","--no-renames","-z",base).split("\0")
    untracked = git(workspace,"ls-files","--others","--exclude-standard","-z").split("\0")
    for name in set(tracked + untracked) - {""}:
        editable(name,scopes)
    return sorted(set(tracked+untracked)-{""})


def develop_run(settings, project, change, token, checks_path, out, rounds=3, execute_checks=False):
    coordinator = Coordinator(project)
    coordinator.get_claim(change,token)
    lock = coordinator.root / ".teamflow" / f"worker-{change}.lock"
    try:
        fd = os.open(lock,os.O_CREAT | os.O_EXCL | os.O_WRONLY,0o600)
    except FileExistsError:
        raise TeamFlowError("worker already active or stale worker lock exists; stop the earlier worker before removing its lock") from None
    try:
        with os.fdopen(fd,"w") as f:
            f.write(str(os.getpid()))
        return _develop_run(settings,project,change,token,checks_path,out,rounds,execute_checks)
    finally:
        lock.unlink(missing_ok=True)


def _develop_run(settings, project, change, token, checks_path, out, rounds=3, execute_checks=False):
    if not execute_checks:
        raise TeamFlowError("execution requires --execute-checks for the operator-configured check commands")
    if not 1 <= rounds <= 6:
        raise TeamFlowError("max-rounds must be in 1..6")
    coordinator = Coordinator(project)
    claim = coordinator.get_claim(change,token)
    if not claim["workspace"] or not claim["base_commit"]:
        raise TeamFlowError("create a claimed worktree first")
    workspace = Path(claim["workspace"]).resolve()
    if Path(git(workspace,"rev-parse","--show-toplevel").strip()).resolve() != workspace:
        raise TeamFlowError("workspace is not a Git worktree root")
    if git(workspace,"rev-parse","HEAD").strip() != claim["base_commit"] or git(workspace,"status","--porcelain").strip():
        raise TeamFlowError("development must start from the clean claimed base; review earlier edits before another run")
    if Path(out).resolve().is_relative_to(workspace):
        raise TeamFlowError("--out must be outside the worktree")
    checks = load_checks(checks_path,coordinator.tasks[change]["acceptance_tests"],workspace)
    trace = Trace(Path(out))
    client = Client(settings,trace)
    task = coordinator.tasks[change]
    spec_dir = coordinator.root / "openspec/changes" / change
    artifacts = {p.relative_to(spec_dir).as_posix():p.read_text() for p in sorted(spec_dir.rglob("*")) if p.is_file()}
    feedback = None
    trace.save("task.json",task)
    trace.save("checks.json",checks)
    trace.emit("development_started",change_id=change,base_commit=claim["base_commit"],
               checks_sha256=digest(checks),plan_sha256=claim["fingerprint"])
    try:
        for attempt in range(1,rounds+1):
            coordinator.get_claim(change,token)
            raw = client.chat("develop",{"stage":"develop","attempt":attempt,"task":task,"artifacts":artifacts,
                "workspace":context_files(workspace,task),"checks":checks,"feedback":feedback,
                "output_shape":{"summary":"what changed","files":[{"path":"repository/relative/path","content":"whole new text"}]},
                "instructions":"Implement only this task. Never edit OpenSpec, teamflow metadata, hidden files or acceptance tests "
                "to make them pass. Do not output shell commands. Return whole text for modified/new files only. No deletes. "
                "If a required contract change is outside scope, report the blocker by returning files:[] with a summary."
            },SYSTEM)
            trace.save(f"responses/develop-{attempt}.txt",raw)
            try:
                obj = parse_object(raw)
                changed = apply_files(workspace,obj,task["paths_write"])
                trace.emit("files_applied",attempt=attempt,files=changed)
                results = run_checks(checks,workspace,trace,attempt,client.key_env)
                all_changed = assert_scope(workspace,claim["base_commit"],task["paths_write"])
                if all(r["passed"] for r in results):
                    coordinator.get_claim(change,token)
                    result = {"state":"READY_FOR_REVIEW","change_id":change,"workspace":str(workspace),
                              "attempts":attempt,"changed_files":all_changed,"checks":results,
                              "plan_sha256":claim["fingerprint"],"usage":trace.summary(),
                              "delivery_complete":False,"integration_approved":False}
                    trace.save("result.json",result)
                    trace.emit("development_ready",attempts=attempt)
                    return result
                feedback = {"kind":"acceptance_failed","results":results}
            except (ValueError, KeyError, TypeError) as exc:
                feedback = {"kind":"validation_failed","error":str(exc)}
                trace.emit("edit_rejected",attempt=attempt,error=str(exc))
        raise TeamFlowError(f"development did not pass after {rounds} rounds; inspect retained worktree and logs")
    except Exception as exc:
        trace.emit("development_failed",error=str(exc))
        trace.save("result.json",{"state":"BLOCKED","error":str(exc),"delivery_complete":False,"usage":trace.summary()})
        raise
