# Changelog

## 0.2.0 — 2026-10-15

- Added configurable OpenAI-compatible Chat Completions client and doctor.
- Added bounded LLM planning and OpenSpec artifact repair loops.
- Added scoped code editing with actual test feedback and per-worker lock.
- Added batch execution with one active worker per member and dependency gates.
- Retained single-host SQLite admission, Git worktrees and operator integration receipts.
- Added real automated tests, explicit mock HTTP demo and reproducible evidence.
- Added MIT release materials. Public repository and real-team pilot remain pending.
