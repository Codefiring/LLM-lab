## Purpose

Describe the new capability in at least fifty characters.

## ADDED Requirements

### Requirement: Observable behavior
The system SHALL ...

#### Scenario: Acceptance case
- **WHEN** ...
- **THEN** ...
