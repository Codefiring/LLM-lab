#!/usr/bin/env python3
"""Single-host admission and handoff reference implementation, not a sandbox or CI service."""
from __future__ import annotations
import argparse
import datetime as dt
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import sqlite3
import subprocess
import sys
import uuid
from . import planning as core
from . import openspec as native
from .workflow import validate_plan

FIELDS = ['depends_on', 'required_skills', 'paths_write', 'acceptance_tests', 'contract_version']


def now():
    return dt.datetime.now(dt.timezone.utc).isoformat()


class Coordinator:
    def __init__(self, root):
        self.root = Path(root).resolve()
        self.plan = core.read_json(self.root / 'teamflow/plan.json')
        self.manifest = core.read_json(self.root / 'teamflow/requirements.json')
        self.team = core.read_json(self.root / 'teamflow/members.json')
        validate_plan(self.plan, self.manifest, self.team)
        self.tasks = {t['id']: t for t in self.plan['tasks']}
        self.members = {m['id']: m for m in self.team['members']}
        for tid, task in self.tasks.items():
            if not re.fullmatch('[a-z][a-z0-9-]*', tid):
                raise ValueError('OpenSpec change IDs must be lower-case kebab names')
            actual = core.read_json(self.root / f'openspec/changes/{tid}/handoff.json')
            expected = {'change_id': tid, **{k: task[k] for k in FIELDS}}
            if actual != expected:
                raise ValueError(f'handoff drift: {tid}')

    def openspec(self, *args):
        return native.invoke(self.root, *args)

    def readiness(self, tid):
        if tid not in self.tasks:
            raise ValueError('unknown change')
        status = self.openspec('status', '--change', tid, '--json')
        if not status.get('isPlanningComplete', status.get('isComplete', False)):
            raise ValueError('planning artifacts incomplete')
        self.openspec('validate', tid, '--strict', '--no-interactive', '--json')
        return status

    def fingerprint(self):
        h = hashlib.sha256()
        paths = list((self.root / 'teamflow').glob('*.json'))
        paths += list((self.root / 'openspec/changes').rglob('*'))
        paths += list((self.root / 'openspec/schemas/team-parallel').rglob('*'))
        paths += [self.root / 'openspec/config.yaml']
        for p in sorted(p for p in paths if p.is_file()):
            data = p.read_bytes()
            if p.name == 'tasks.md':
                data = re.sub(rb'\[[ xX]\]', b'[ ]', data)
            h.update(str(p.relative_to(self.root)).encode() + b'\0' + data + b'\0')
        return h.hexdigest()

    def db(self):
        directory = self.root / '.teamflow'
        directory.mkdir(exist_ok=True)
        db = sqlite3.connect(directory / 'state.sqlite', timeout=15)
        db.row_factory = sqlite3.Row
        db.execute('CREATE TABLE IF NOT EXISTS claims (change_id TEXT PRIMARY KEY, owner TEXT, token TEXT, state TEXT, fingerprint TEXT, base_commit TEXT, workspace TEXT)')
        db.execute('CREATE TABLE IF NOT EXISTS events (seq INTEGER PRIMARY KEY AUTOINCREMENT, timestamp_utc TEXT, event TEXT, payload TEXT)')
        return db

    @staticmethod
    def event(db, event, **data):
        db.execute('INSERT INTO events(timestamp_utc,event,payload) VALUES(?,?,?)',
                   (now(), event, json.dumps(data, ensure_ascii=False)))

    def claim(self, tid, owner):
        self.readiness(tid)
        if owner not in self.members:
            raise ValueError('unknown owner')
        task = self.tasks[tid]
        if not set(task['required_skills']) <= set(self.members[owner]['skills']):
            raise ValueError('owner skills do not cover this change')
        fingerprint = self.fingerprint()
        db = self.db()
        try:
            db.execute('BEGIN IMMEDIATE')
            rows = [dict(r) for r in db.execute('SELECT * FROM claims')]
            completed = {r['change_id'] for r in rows if r['state'] == 'integrated'}
            if not set(task['depends_on']) <= completed:
                raise ValueError('dependencies not integrated')
            if any(r['change_id'] == tid for r in rows):
                raise ValueError('change already claimed or integrated')
            for row in rows:
                if row['state'] != 'claimed':
                    continue
                if row['fingerprint'] != fingerprint:
                    raise ValueError('planning changed while work is active; stop and reconcile')
                if row['owner'] == owner:
                    raise ValueError('owner capacity is one active change')
                if core.conflicts(task, self.tasks[row['change_id']]):
                    raise ValueError('write path or shared resource conflict')
            token = str(uuid.uuid4())
            db.execute('INSERT INTO claims VALUES(?,?,?,?,?,?,?)',
                       (tid, owner, token, 'claimed', fingerprint, None, None))
            self.event(db, 'change_claimed', change_id=tid, owner=owner, plan_sha256=fingerprint)
            db.commit()
            return {'change_id': tid, 'owner': owner, 'token': token, 'state': 'claimed',
                    'plan_sha256': fingerprint, 'warning': 'Single-host advisory coordination; not a security boundary.'}
        except Exception:
            db.rollback()
            raise
        finally:
            db.close()

    def get_claim(self, tid, token, check_fingerprint=True):
        db = self.db()
        try:
            row = db.execute('SELECT * FROM claims WHERE change_id=? AND token=? AND state=?',
                             (tid, token, 'claimed')).fetchone()
            if not row:
                raise ValueError('matching active claim required')
            if check_fingerprint and row['fingerprint'] != self.fingerprint():
                raise ValueError('planning fingerprint changed; reconcile before continuing')
            return dict(row)
        finally:
            db.close()

    def packet(self, tid, token):
        claim = self.get_claim(tid, token)
        instructions = self.openspec('instructions', 'apply', '--change', tid, '--json')
        return {'change_id': tid, 'owner': claim['owner'], 'plan_sha256': claim['fingerprint'],
                'handoff': core.read_json(self.root / f'openspec/changes/{tid}/handoff.json'),
                'openspec_apply': instructions,
                'source_refs': [r['source'] for r in self.manifest['requirements']
                                if r['id'] in self.tasks[tid]['requirements']],
                'agent_instruction': 'Read referenced files. Implement in the assigned worktree. Only change allowed paths. Run actual acceptance checks; do not fabricate results. Do not archive or sync. Report blockers and contract changes.',
                'delivery_complete': False}

    def git(self, *args, check=True):
        r = subprocess.run(['git', *args], cwd=self.root, text=True, capture_output=True, timeout=60)
        if check and r.returncode:
            raise ValueError(r.stderr.strip() or 'git command failed')
        return r

    def workspace(self, tid, token, destination):
        claim = self.get_claim(tid, token)
        if claim["workspace"]:
            raise ValueError("worktree already exists for this claim")
        if Path(self.git('rev-parse', '--show-toplevel').stdout.strip()).resolve() != self.root:
            raise ValueError('--root must be the Git repository root')
        if self.git('status', '--porcelain').stdout.strip():
            raise ValueError('commit the reviewed planning snapshot before creating a worktree')
        target = Path(destination).resolve()
        if target.exists():
            raise ValueError('worktree destination must not exist')
        head = self.git('rev-parse', 'HEAD').stdout.strip()
        branch = f'teamflow/{tid}-{token[:8]}'
        self.git('worktree', 'add', '-b', branch, str(target), head)
        db = self.db()
        try:
            db.execute('UPDATE claims SET base_commit=?, workspace=? WHERE change_id=? AND token=?',
                       (head, str(target), tid, token))
            self.event(db, 'worktree_created', change_id=tid, base_commit=head, branch=branch, path=str(target))
            db.commit()
        finally:
            db.close()
        return {'branch': branch, 'path': str(target), 'base_commit': head}

    def record_integrated(self, tid, token, receipt):
        """Import an operator-reviewed CI attestation; no CI authentication is implemented here."""
        row = self.get_claim(tid, token)
        if receipt.get('change_id') != tid or receipt.get('plan_sha256') != row['fingerprint']:
            raise ValueError('receipt does not match the claim and planning snapshot')
        commit = receipt.get('commit', '')
        if not re.fullmatch('[0-9a-f]{40,64}', commit):
            raise ValueError('receipt needs a full commit hash')
        if not row['base_commit'] or not receipt.get('ci_run_url') or not receipt.get('reviewer'):
            raise ValueError('workspace base, CI URL and independent reviewer required')
        if receipt['reviewer'] == row['owner'] or receipt.get('passed') is not True:
            raise ValueError('independent review and passing CI required')
        if not set(self.tasks[tid]['acceptance_tests']) <= set(receipt.get('passed_acceptance_ids', [])):
            raise ValueError('missing acceptance evidence')
        self.git('merge-base', '--is-ancestor', row['base_commit'], commit)
        self.git('merge-base', '--is-ancestor', commit, 'HEAD')
        if commit == row['base_commit']:
            raise ValueError('base commit alone is not implementation evidence')
        db = self.db()
        try:
            db.execute('UPDATE claims SET state=? WHERE change_id=? AND token=?', ('integrated', tid, token))
            self.event(db, 'integration_attested_by_operator', change_id=tid, receipt=receipt,
                       evidence_boundary='Operator-provided receipt; CI authenticity is not verified by this prototype.')
            db.commit()
        finally:
            db.close()
        return {'change_id': tid, 'state': 'integrated', 'evidence_boundary': 'OPERATOR_ATTESTATION_NOT_AUTHENTICATED_CI'}

    def release(self, tid, token, reason):
        self.get_claim(tid, token, check_fingerprint=False)
        db = self.db()
        try:
            db.execute('DELETE FROM claims WHERE change_id=? AND token=? AND state=?', (tid, token, 'claimed'))
            self.event(db, 'claim_released_after_operator_stop', change_id=tid, reason=reason)
            db.commit()
        finally:
            db.close()
        return {'released': tid, 'note': 'Existing worker processes and worktrees are not stopped or deleted.'}

    def states(self):
        db = self.db()
        try:
            return {'claims': [dict(r) for r in db.execute('SELECT change_id,owner,state,base_commit,workspace FROM claims ORDER BY change_id')],
                    'events': [dict(r) for r in db.execute('SELECT * FROM events ORDER BY seq')]}
        finally:
            db.close()

