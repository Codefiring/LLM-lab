from __future__ import annotations
import datetime as dt
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import re
import subprocess
import tempfile
import threading
import time
import uuid


class TeamFlowError(ValueError):
    pass


def read_json(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))


def write_json(path, value):
    atomic_write(path, json.dumps(value, ensure_ascii=False, indent=2) + "\n")


def atomic_write(path, text):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, name = tempfile.mkstemp(prefix=".teamflow-write-", dir=path.parent)
    try:
        with os.fdopen(fd, "w", encoding="utf-8", newline="\n") as f:
            f.write(text)
        os.replace(name, path)
    finally:
        if os.path.exists(name):
            os.unlink(name)


def digest(value):
    data = value if isinstance(value, bytes) else json.dumps(value, sort_keys=True, ensure_ascii=False).encode()
    return hashlib.sha256(data).hexdigest()


def safe_relative(value):
    if not isinstance(value, str) or not value or value.startswith("/") or "\\" in value or ":" in value:
        raise TeamFlowError(f"invalid relative path: {value!r}")
    parts = value.rstrip("/").split("/")
    if any(x in ("", ".", "..") for x in parts) or any(x in value for x in "*?[]\x00\r\n"):
        raise TeamFlowError(f"invalid relative path: {value!r}")
    if PurePosixPath(value).is_absolute():
        raise TeamFlowError("absolute paths are not allowed")
    return "/".join(parts)


def scoped_path(root, relative):
    root = Path(root).resolve()
    name = safe_relative(relative)
    p = root
    for part in name.split("/"):
        p = p / part
        if p.is_symlink():
            raise TeamFlowError(f"symlink is not allowed: {relative}")
    if not p.resolve().is_relative_to(root):
        raise TeamFlowError("path escapes workspace")
    return p


def within(path, prefix):
    a, b = safe_relative(path), safe_relative(prefix)
    return a == b or a.startswith(b + "/")


def parse_object(text):
    text = text.strip()
    if text.startswith("<think>"):
        if "</think>" not in text:
            raise TeamFlowError("unclosed thinking block; increase generation budget or disable thinking")
        text = text.split("</think>", 1)[1].strip()
    if text.startswith("```"):
        lines = text.splitlines()
        if lines[-1].strip() != "```":
            raise TeamFlowError("unclosed JSON code fence")
        text = "\n".join(lines[1:-1])
    try:
        result = json.loads(text)
    except json.JSONDecodeError as e:
        raise TeamFlowError(f"response must contain one JSON object: {e.msg} at {e.pos}") from e
    if not isinstance(result, dict):
        raise TeamFlowError("response must be a JSON object")
    return result


class Trace:
    def __init__(self, directory, resume=False, secrets=()):
        self.root = Path(directory)
        self.root.mkdir(parents=True, exist_ok=resume)
        self.events = self.root / "events.jsonl"
        self.run_id = str(uuid.uuid4())
        self.secrets = tuple(x for x in secrets if x)
        self.lock = threading.Lock()
        self.started = time.monotonic()
        self.http_attempts = 0
        self.reported_tokens = 0
        self.missing_usage = False
        self.mock_provider = False
        if resume and self.events.exists():
            for line in self.events.read_text().splitlines():
                r = json.loads(line)
                self.http_attempts += r["event"] == "http_attempt"
                if r["event"] == "llm_response":
                    self.reported_tokens += r.get("reported_total_tokens") or 0
                    self.missing_usage |= r.get("reported_total_tokens") is None
                    self.mock_provider |= r.get("test_double", False)

    def redact(self, value):
        text = value if isinstance(value, str) else json.dumps(value, ensure_ascii=False)
        for secret in self.secrets:
            text = text.replace(secret, "[REDACTED]")
        return text

    def save(self, name, value):
        p = scoped_path(self.root, name)
        atomic_write(p, self.redact(value) + "\n")

    def emit(self, event, **data):
        row = {"run_id": self.run_id, "timestamp_utc": dt.datetime.now(dt.timezone.utc).isoformat(),
               "event": event, **data}
        with self.lock, self.events.open("a", encoding="utf-8") as f:
            f.write(self.redact(row) + "\n")

    def summary(self):
        return {"http_attempts": self.http_attempts, "server_reported_tokens": self.reported_tokens,
                "usage_incomplete": self.missing_usage, "test_double_observed": self.mock_provider,
                "billing_verified": False, "runtime_seconds": round(time.monotonic() - self.started, 3)}


def run_process(argv, cwd, timeout=60):
    r = subprocess.run(argv, cwd=cwd, text=True, encoding="utf-8", errors="replace",
                       capture_output=True, timeout=timeout, shell=False)
    if r.returncode:
        raise TeamFlowError(f"command failed ({r.returncode}): {argv[0]}\n{r.stderr[-4000:]}\n{r.stdout[-4000:]}")
    return r.stdout


def git(root, *args):
    return run_process(["git", *args], root)
