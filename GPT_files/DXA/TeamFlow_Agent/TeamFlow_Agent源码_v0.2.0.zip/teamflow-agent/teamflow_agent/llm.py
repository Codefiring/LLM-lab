"""Minimal OpenAI Chat Completions HTTP client; no cloud fallback, tools or SDK dependency."""
from __future__ import annotations
import json
import math
import os
import socket
import time
import urllib.error
import urllib.parse
import urllib.request
import uuid
from .common import TeamFlowError, read_json


class NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        return None


class Client:
    def __init__(self, settings, trace):
        cfg = dict(settings)
        allowed = {"base_url", "model", "api_key_env", "timeout_seconds", "http_retries", "retry_delay_seconds",
                   "max_tokens", "temperature", "json_mode", "extra_body", "max_http_calls", "max_reported_tokens",
                   "token_limit_field", "trust_environment_proxy", "max_response_bytes", "max_request_bytes"}
        if set(cfg) - allowed:
            raise TeamFlowError("unknown LLM configuration keys: " + ", ".join(sorted(set(cfg)-allowed)))
        cfg["base_url"] = os.environ.get("TEAMFLOW_BASE_URL", cfg.get("base_url", ""))
        cfg["model"] = os.environ.get("TEAMFLOW_MODEL", cfg.get("model", ""))
        url = urllib.parse.urlsplit(cfg["base_url"])
        if url.scheme not in ("http", "https") or not url.netloc or url.username or url.password or url.query or url.fragment:
            raise TeamFlowError("base_url must be an HTTP(S) API root without credentials, query or fragment")
        base = cfg["base_url"].rstrip("/")
        if base.endswith("/chat/completions"):
            base = base[:-len("/chat/completions")]
        self.base_url = base
        self.model = cfg["model"]
        if not isinstance(self.model, str) or not self.model.strip():
            raise TeamFlowError("model is required; use the server's served model name")
        self.key_env = cfg.get("api_key_env", "TEAMFLOW_API_KEY")
        self.key = os.environ.get(self.key_env, "") if self.key_env else ""
        self.trace = trace
        if self.key:
            trace.secrets += (self.key,)
        self.timeout = cfg.get("timeout_seconds", 120)
        self.retries = cfg.get("http_retries", 2)
        self.delay = cfg.get("retry_delay_seconds", 1)
        self.max_calls = cfg.get("max_http_calls", 80)
        self.max_reported_tokens = cfg.get("max_reported_tokens", 200000)
        self.max_bytes = cfg.get("max_response_bytes", 8 * 1024 * 1024)
        self.max_request_bytes = cfg.get("max_request_bytes", 2 * 1024 * 1024)
        for name, value in [("timeout_seconds", self.timeout), ("max_tokens", cfg.get("max_tokens", 8192)),
                            ("max_http_calls", self.max_calls), ("max_response_bytes", self.max_bytes),
                            ("max_request_bytes", self.max_request_bytes), ("max_reported_tokens", self.max_reported_tokens)]:
            if isinstance(value, bool) or not isinstance(value, (int, float)) or not math.isfinite(value) or value <= 0:
                raise TeamFlowError(f"{name} must be a finite positive number")
        if not isinstance(self.retries, int) or isinstance(self.retries, bool) or not 0 <= self.retries <= 5:
            raise TeamFlowError("http_retries must be between 0 and 5")
        if not isinstance(self.delay, (float,int)) or not 0 <= self.delay <= 30:
            raise TeamFlowError("retry_delay_seconds must be between 0 and 30")
        self.token_field = cfg.get("token_limit_field", "max_tokens")
        if self.token_field not in ("max_tokens", "max_completion_tokens"):
            raise TeamFlowError("invalid token_limit_field")
        extra = cfg.get("extra_body", {})
        if not isinstance(extra, dict) or set(extra) & {"model", "messages", "stream", "tools", "tool_choice", "response_format", "max_tokens", "max_completion_tokens", "temperature"}:
            raise TeamFlowError("extra_body cannot override controlled request fields")
        if not isinstance(cfg.get("json_mode", False), bool):
            raise TeamFlowError("json_mode must be a boolean")
        self.cfg = cfg
        handlers = [NoRedirect()]
        if not cfg.get("trust_environment_proxy", False):
            handlers.append(urllib.request.ProxyHandler({}))
        self.opener = urllib.request.build_opener(*handlers)

    def request(self, path, body=None, stage="doctor"):
        raw = json.dumps(body, ensure_ascii=False).encode() if body is not None else None
        if raw is not None and len(raw) > self.max_request_bytes:
            raise TeamFlowError("request exceeds max_request_bytes; reduce context")
        headers = {"Content-Type": "application/json", "Accept": "application/json"}
        if self.key:
            headers["Authorization"] = "Bearer " + self.key
        for attempt in range(self.retries + 1):
            if self.trace.http_attempts >= self.max_calls:
                raise TeamFlowError("HTTP call budget exhausted")
            if self.trace.reported_tokens >= self.max_reported_tokens:
                raise TeamFlowError("server-reported token budget exhausted")
            self.trace.http_attempts += 1
            request_id = str(uuid.uuid4())
            headers["X-Request-ID"] = request_id
            self.trace.emit("http_attempt", request_id=request_id, stage=stage, attempt=attempt+1)
            req = urllib.request.Request(self.base_url + path, data=raw, headers=headers, method="POST" if raw else "GET")
            started = time.monotonic()
            try:
                with self.opener.open(req, timeout=self.timeout) as response:
                    payload = response.read(int(self.max_bytes) + 1)
                    is_mock = response.headers.get("X-TeamFlow-Test-Double") == "true"
                if len(payload) > self.max_bytes:
                    raise TeamFlowError("response exceeds max_response_bytes")
                value = json.loads(payload)
                if not isinstance(value, dict):
                    raise TeamFlowError("API response must be a JSON object")
                self.trace.mock_provider |= is_mock
                return value, {"latency_seconds":round(time.monotonic()-started,3), "test_double":is_mock, "request_id":request_id}
            except urllib.error.HTTPError as exc:
                retry = exc.code in (408, 429, 500, 502, 503, 504)
                # Never record server error bodies: they can echo credentials or private infrastructure.
                message = f"HTTP {exc.code} from configured LLM server"
                if exc.code == 400:
                    message += "; check model, max_tokens, extra_body and json_mode"
                self.trace.emit("http_error", stage=stage, status=exc.code, retrying=retry and attempt<self.retries)
                if not retry or attempt == self.retries:
                    raise TeamFlowError(message) from None
            except (urllib.error.URLError, socket.timeout, TimeoutError, ConnectionError) as exc:
                self.trace.emit("http_transport_error", stage=stage, type=type(exc).__name__, retrying=attempt<self.retries)
                if attempt == self.retries:
                    raise TeamFlowError("LLM server connection failed or timed out; check the configured address and service") from None
            except (json.JSONDecodeError, UnicodeDecodeError):
                raise TeamFlowError("LLM server did not return valid JSON") from None
            time.sleep(min(self.delay * (2**attempt), 30))
        raise TeamFlowError("HTTP retry loop exhausted")

    def chat(self, stage, payload, system):
        body = {"model": self.model, "messages": [{"role":"system","content":system},
                {"role":"user","content":json.dumps(payload,ensure_ascii=False)}], "stream":False,
                self.token_field:self.cfg.get("max_tokens",8192), **self.cfg.get("extra_body",{})}
        temperature = self.cfg.get("temperature", 0.1)
        if temperature is not None:
            body["temperature"] = temperature
        if self.cfg.get("json_mode",False):
            body["response_format"] = {"type":"json_object"}
        data, metadata = self.request("/chat/completions", body, stage)
        try:
            choice = data["choices"][0]
            message = choice["message"]
            content = message.get("content")
        except (KeyError, IndexError, TypeError):
            raise TeamFlowError("response is missing choices[0].message") from None
        usage = data.get("usage") or {}
        total = usage.get("total_tokens") if isinstance(usage,dict) else None
        if not isinstance(total,int) or isinstance(total,bool) or total < 0:
            total = None
        self.trace.reported_tokens += total or 0
        self.trace.missing_usage |= total is None
        self.trace.emit("llm_response", stage=stage, response_id=data.get("id"), model=data.get("model",self.model),
                        reported_total_tokens=total, finish_reason=choice.get("finish_reason"), **metadata)
        if choice.get("finish_reason") == "length":
            raise TeamFlowError("model output was truncated; increase max_tokens or reduce task size")
        if isinstance(content,list):
            content = "".join(x.get("text", "") for x in content if isinstance(x,dict) and x.get("type") == "text")
        if not isinstance(content,str) or not content.strip():
            raise TeamFlowError("empty message.content; reasoning_content/tool_calls are not final JSON output")
        return content

    def doctor(self):
        models = None
        models_error = None
        try:
            data, _ = self.request("/models")
            models = [x.get("id") for x in data.get("data",[]) if isinstance(x,dict)]
        except TeamFlowError as exc:
            models_error = str(exc)
        raw = self.chat("doctor", {"stage":"doctor","instruction":"Return {\"ok\":true} only."}, "Return a JSON object, no commentary.")
        from .common import parse_object
        if parse_object(raw).get("ok") is not True:
            raise TeamFlowError("chat endpoint responded but did not follow the JSON check")
        return {"chat_ok":True,"configured_model":self.model,"available_models":models,"models_endpoint_error":models_error,
                "usage":self.trace.summary()}
