import asyncio
import hashlib
import json
import time
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Tuple

import httpx
import yaml
from fastapi import FastAPI, Request, HTTPException
from fastapi.responses import JSONResponse, StreamingResponse, PlainTextResponse
from prometheus_client import Counter, Gauge, Histogram, generate_latest, CONTENT_TYPE_LATEST


# =========================
# Metrics
# =========================

REQ_TOTAL = Counter("llm_router_requests_total", "Total routed requests", ["endpoint", "backend", "status"])
REQ_LATENCY = Histogram("llm_router_request_seconds", "Router request latency", ["endpoint", "backend"])
BACKEND_UP = Gauge("llm_router_backend_up", "Backend health status", ["backend"])
BACKEND_INFLIGHT = Gauge("llm_router_backend_inflight", "Backend inflight requests", ["backend"])
BACKEND_SCORE = Gauge("llm_router_backend_score", "Backend scheduling score", ["backend"])
BACKEND_ERRORS = Gauge("llm_router_backend_errors", "Backend recent error count", ["backend"])


# =========================
# Config / State
# =========================

@dataclass
class Backend:
    name: str
    base_url: str
    model: str
    api_key: Optional[str] = None
    max_inflight: int = 128

    healthy: bool = False
    inflight: int = 0
    consecutive_failures: int = 0

    # vLLM metrics snapshot
    running: float = 0.0
    waiting: float = 0.0
    kv_cache_usage: float = 0.0
    avg_latency: float = 0.0
    last_health_ts: float = 0.0
    last_error: str = ""

    lock: asyncio.Lock = field(default_factory=asyncio.Lock)


class PrefixAffinity:
    def __init__(self, ttl_seconds: int):
        self.ttl = ttl_seconds
        self.store: Dict[str, Tuple[str, float]] = {}

    def get(self, key: str) -> Optional[str]:
        item = self.store.get(key)
        if not item:
            return None
        backend_name, ts = item
        if time.time() - ts > self.ttl:
            self.store.pop(key, None)
            return None
        return backend_name

    def set(self, key: str, backend_name: str):
        self.store[key] = (backend_name, time.time())

    def cleanup(self):
        now = time.time()
        expired = [k for k, (_, ts) in self.store.items() if now - ts > self.ttl]
        for k in expired:
            self.store.pop(k, None)


def load_config(path: str = "config.yaml") -> dict:
    with open(path, "r", encoding="utf-8") as f:
        return yaml.safe_load(f)


CFG = load_config()
ROUTER_CFG = CFG["router"]
SCORING = CFG["scoring"]
BACKENDS: Dict[str, Backend] = {
    b["name"]: Backend(**b) for b in CFG["backends"]
}
PREFIX = PrefixAffinity(ttl_seconds=ROUTER_CFG.get("prefix_cache_ttl_seconds", 1800))

app = FastAPI(title="LLM Router for vLLM", version="1.0.0")


# =========================
# Helpers
# =========================

def require_router_auth(req: Request):
    expected = ROUTER_CFG.get("api_key")
    if not expected:
        return

    auth = req.headers.get("authorization", "")
    if not auth.startswith("Bearer "):
        raise HTTPException(status_code=401, detail="Missing Bearer token")

    token = auth.removeprefix("Bearer ").strip()
    if token != expected:
        raise HTTPException(status_code=403, detail="Invalid router token")


def extract_text_for_prefix(payload: dict) -> str:
    """
    Prefix-aware routing:
    - Chat API: use system + first user messages as stable prefix.
    - Completion API: use beginning of prompt.
    """
    if "messages" in payload:
        parts = []
        for m in payload.get("messages", [])[:3]:
            role = m.get("role", "")
            content = m.get("content", "")
            if isinstance(content, list):
                content = json.dumps(content, ensure_ascii=False)
            parts.append(f"{role}:{content}")
        return "\n".join(parts)[:4096]

    prompt = payload.get("prompt", "")
    if isinstance(prompt, list):
        prompt = json.dumps(prompt, ensure_ascii=False)
    return str(prompt)[:4096]


def prefix_key(payload: dict) -> str:
    model = payload.get("model", "")
    stable_prefix = extract_text_for_prefix(payload)
    raw = f"{model}\n{stable_prefix}"
    return hashlib.sha256(raw.encode("utf-8")).hexdigest()


def parse_prometheus_metrics(text: str) -> dict:
    """
    尽量兼容 vLLM 不同版本的 metrics 命名。
    找不到时就保持默认值，不影响转发。
    """
    result = {
        "running": 0.0,
        "waiting": 0.0,
        "kv_cache_usage": 0.0,
    }

    for line in text.splitlines():
        if not line or line.startswith("#"):
            continue

        try:
            name_part, value_part = line.rsplit(" ", 1)
            value = float(value_part)
        except Exception:
            continue

        metric_name = name_part.split("{", 1)[0]

        # 常见 vLLM metrics 名称，不同版本可能略有差异
        if metric_name in {
            "vllm:num_requests_running",
            "vllm_num_requests_running",
        }:
            result["running"] = value

        elif metric_name in {
            "vllm:num_requests_waiting",
            "vllm_num_requests_waiting",
        }:
            result["waiting"] = value

        elif metric_name in {
            "vllm:gpu_cache_usage_perc",
            "vllm_gpu_cache_usage_perc",
            "vllm:kv_cache_usage_perc",
            "vllm_kv_cache_usage_perc",
        }:
            result["kv_cache_usage"] = max(result["kv_cache_usage"], value)

    return result


def backend_score(backend: Backend, preferred_backend_name: Optional[str] = None) -> float:
    s = 0.0
    s += SCORING["queue_weight"] * backend.inflight
    s += SCORING["running_weight"] * backend.running
    s += SCORING["waiting_weight"] * backend.waiting
    s += SCORING["kv_cache_weight"] * backend.kv_cache_usage
    s += SCORING["latency_weight"] * backend.avg_latency
    s += SCORING["error_weight"] * backend.consecutive_failures

    if preferred_backend_name == backend.name:
        s += SCORING.get("prefix_bonus", -5.0)

    return s


async def choose_backend(payload: dict) -> Tuple[Backend, str]:
    preferred_name = None
    pkey = prefix_key(payload)

    if ROUTER_CFG.get("enable_prefix_affinity", True):
        preferred_name = PREFIX.get(pkey)

    candidates = []
    for b in BACKENDS.values():
        if not b.healthy:
            continue
        if b.inflight >= b.max_inflight:
            continue
        candidates.append(b)

    if not candidates:
        raise HTTPException(status_code=503, detail="No healthy vLLM backend available")

    selected = min(candidates, key=lambda b: backend_score(b, preferred_name))

    if ROUTER_CFG.get("enable_prefix_affinity", True):
        PREFIX.set(pkey, selected.name)

    return selected, pkey


async def mark_failure(backend: Backend, err: str):
    async with backend.lock:
        backend.consecutive_failures += 1
        backend.last_error = err
        threshold = ROUTER_CFG.get("backend_failure_threshold", 3)
        if backend.consecutive_failures >= threshold:
            backend.healthy = False

    BACKEND_ERRORS.labels(backend=backend.name).set(backend.consecutive_failures)
    BACKEND_UP.labels(backend=backend.name).set(1 if backend.healthy else 0)


async def mark_success(backend: Backend, latency: float):
    async with backend.lock:
        backend.consecutive_failures = 0
        backend.healthy = True
        # EMA latency
        if backend.avg_latency <= 0:
            backend.avg_latency = latency
        else:
            backend.avg_latency = backend.avg_latency * 0.8 + latency * 0.2

    BACKEND_ERRORS.labels(backend=backend.name).set(0)
    BACKEND_UP.labels(backend=backend.name).set(1)


def backend_headers(backend: Backend, incoming: Request) -> dict:
    headers = {
        "content-type": "application/json",
    }
    if backend.api_key:
        headers["authorization"] = f"Bearer {backend.api_key}"

    # 透传部分 tracing headers
    for h in ["x-request-id", "traceparent"]:
        if h in incoming.headers:
            headers[h] = incoming.headers[h]
    return headers


# =========================
# Health Monitor
# =========================

async def poll_backend(backend: Backend):
    timeout = httpx.Timeout(5.0)
    async with httpx.AsyncClient(timeout=timeout) as client:
        try:
            health = await client.get(f"{backend.base_url}/health")
            ok = health.status_code < 500

            metrics_snapshot = {}
            try:
                metrics = await client.get(f"{backend.base_url}/metrics")
                if metrics.status_code == 200:
                    metrics_snapshot = parse_prometheus_metrics(metrics.text)
            except Exception:
                pass

            async with backend.lock:
                backend.healthy = ok
                backend.last_health_ts = time.time()
                if ok:
                    backend.consecutive_failures = 0
                    backend.last_error = ""

                backend.running = metrics_snapshot.get("running", backend.running)
                backend.waiting = metrics_snapshot.get("waiting", backend.waiting)
                backend.kv_cache_usage = metrics_snapshot.get("kv_cache_usage", backend.kv_cache_usage)

        except Exception as e:
            async with backend.lock:
                backend.consecutive_failures += 1
                backend.last_error = repr(e)
                threshold = ROUTER_CFG.get("backend_failure_threshold", 3)
                if backend.consecutive_failures >= threshold:
                    backend.healthy = False

    BACKEND_UP.labels(backend=backend.name).set(1 if backend.healthy else 0)
    BACKEND_INFLIGHT.labels(backend=backend.name).set(backend.inflight)
    BACKEND_ERRORS.labels(backend=backend.name).set(backend.consecutive_failures)
    BACKEND_SCORE.labels(backend=backend.name).set(backend_score(backend))


async def health_loop():
    while True:
        await asyncio.gather(*(poll_backend(b) for b in BACKENDS.values()))
        PREFIX.cleanup()
        await asyncio.sleep(ROUTER_CFG.get("health_interval_seconds", 5))


@app.on_event("startup")
async def startup():
    for b in BACKENDS.values():
        BACKEND_UP.labels(backend=b.name).set(0)
        BACKEND_INFLIGHT.labels(backend=b.name).set(0)
        BACKEND_ERRORS.labels(backend=b.name).set(0)
    asyncio.create_task(health_loop())


# =========================
# Proxy Logic
# =========================

async def proxy_json(endpoint: str, request: Request):
    require_router_auth(request)
    payload = await request.json()

    last_error = None
    max_retries = ROUTER_CFG.get("max_retries", 2)

    for attempt in range(max_retries + 1):
        backend, _ = await choose_backend(payload)

        async with backend.lock:
            backend.inflight += 1
        BACKEND_INFLIGHT.labels(backend=backend.name).set(backend.inflight)

        start = time.time()

        try:
            timeout = httpx.Timeout(ROUTER_CFG.get("request_timeout_seconds", 600))
            async with httpx.AsyncClient(timeout=timeout) as client:
                resp = await client.post(
                    f"{backend.base_url}{endpoint}",
                    json=payload,
                    headers=backend_headers(backend, request),
                )

            latency = time.time() - start
            REQ_LATENCY.labels(endpoint=endpoint, backend=backend.name).observe(latency)

            # 5xx 可以重试；4xx 多数是请求问题，不重试
            if resp.status_code >= 500:
                last_error = f"{backend.name} returned {resp.status_code}: {resp.text[:500]}"
                await mark_failure(backend, last_error)
                REQ_TOTAL.labels(endpoint=endpoint, backend=backend.name, status="backend_5xx").inc()
                continue

            await mark_success(backend, latency)
            REQ_TOTAL.labels(endpoint=endpoint, backend=backend.name, status=str(resp.status_code)).inc()

            return JSONResponse(
                status_code=resp.status_code,
                content=resp.json() if resp.content else {},
                headers={"x-llm-backend": backend.name},
            )

        except Exception as e:
            last_error = repr(e)
            await mark_failure(backend, last_error)
            REQ_TOTAL.labels(endpoint=endpoint, backend=backend.name, status="exception").inc()

        finally:
            async with backend.lock:
                backend.inflight = max(0, backend.inflight - 1)
            BACKEND_INFLIGHT.labels(backend=backend.name).set(backend.inflight)

    raise HTTPException(status_code=502, detail=f"All retries failed: {last_error}")


async def proxy_stream(endpoint: str, request: Request):
    require_router_auth(request)
    payload = await request.json()
    payload["stream"] = True

    backend, _ = await choose_backend(payload)

    async def stream_generator():
        async with backend.lock:
            backend.inflight += 1
        BACKEND_INFLIGHT.labels(backend=backend.name).set(backend.inflight)

        start = time.time()
        timeout = httpx.Timeout(ROUTER_CFG.get("request_timeout_seconds", 600))

        try:
            async with httpx.AsyncClient(timeout=timeout) as client:
                async with client.stream(
                    "POST",
                    f"{backend.base_url}{endpoint}",
                    json=payload,
                    headers=backend_headers(backend, request),
                ) as resp:
                    if resp.status_code >= 500:
                        text = await resp.aread()
                        err = f"{backend.name} stream returned {resp.status_code}: {text[:500]}"
                        await mark_failure(backend, err)
                        yield f"event: error\ndata: {json.dumps({'error': err})}\n\n"
                        return

                    async for chunk in resp.aiter_bytes():
                        yield chunk

            latency = time.time() - start
            await mark_success(backend, latency)
            REQ_LATENCY.labels(endpoint=endpoint, backend=backend.name).observe(latency)
            REQ_TOTAL.labels(endpoint=endpoint, backend=backend.name, status="stream_ok").inc()

        except Exception as e:
            await mark_failure(backend, repr(e))
            REQ_TOTAL.labels(endpoint=endpoint, backend=backend.name, status="stream_exception").inc()
            yield f"event: error\ndata: {json.dumps({'error': repr(e)})}\n\n"

        finally:
            async with backend.lock:
                backend.inflight = max(0, backend.inflight - 1)
            BACKEND_INFLIGHT.labels(backend=backend.name).set(backend.inflight)

    return StreamingResponse(
        stream_generator(),
        media_type="text/event-stream",
        headers={"x-llm-backend": backend.name},
    )


# =========================
# OpenAI-compatible Endpoints
# =========================

@app.post("/v1/chat/completions")
async def chat_completions(request: Request):
    body = await request.json()
    # 重新构造 request 不方便，所以这里走内部函数前把 body 塞回去不做；
    # 简化处理：根据 stream 分流到独立实现
    async def receive():
        return {"type": "http.request", "body": json.dumps(body).encode("utf-8"), "more_body": False}
    request._receive = receive

    if body.get("stream") is True:
        return await proxy_stream("/v1/chat/completions", request)
    return await proxy_json("/v1/chat/completions", request)


@app.post("/v1/completions")
async def completions(request: Request):
    body = await request.json()
    async def receive():
        return {"type": "http.request", "body": json.dumps(body).encode("utf-8"), "more_body": False}
    request._receive = receive

    if body.get("stream") is True:
        return await proxy_stream("/v1/completions", request)
    return await proxy_json("/v1/completions", request)


@app.get("/v1/models")
async def models(request: Request):
    require_router_auth(request)
    # 聚合模型列表：简单返回配置中的模型名
    unique_models = sorted(set(b.model for b in BACKENDS.values()))
    return {
        "object": "list",
        "data": [
            {
                "id": m,
                "object": "model",
                "created": int(time.time()),
                "owned_by": "local-vllm-router",
            }
            for m in unique_models
        ],
    }


# =========================
# Router Ops Endpoints
# =========================

@app.get("/health")
async def health():
    healthy = [b for b in BACKENDS.values() if b.healthy]
    if not healthy:
        return JSONResponse(status_code=503, content={"status": "down", "healthy_backends": 0})
    return {"status": "ok", "healthy_backends": len(healthy), "total_backends": len(BACKENDS)}


@app.get("/backends")
async def backends():
    return {
        name: {
            "base_url": b.base_url,
            "model": b.model,
            "healthy": b.healthy,
            "inflight": b.inflight,
            "running": b.running,
            "waiting": b.waiting,
            "kv_cache_usage": b.kv_cache_usage,
            "avg_latency": b.avg_latency,
            "consecutive_failures": b.consecutive_failures,
            "last_error": b.last_error,
            "score": backend_score(b),
        }
        for name, b in BACKENDS.items()
    }


@app.get("/metrics")
async def metrics():
    return PlainTextResponse(generate_latest(), media_type=CONTENT_TYPE_LATEST)


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(
        "router:app",
        host=ROUTER_CFG.get("host", "0.0.0.0"),
        port=ROUTER_CFG.get("port", 9000),
        reload=False,
    )