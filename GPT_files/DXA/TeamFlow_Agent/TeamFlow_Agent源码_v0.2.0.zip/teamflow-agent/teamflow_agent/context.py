"""Bounded local text indexing with source line references; no embeddings required."""
from pathlib import Path
import re
from .common import TeamFlowError, digest

SUFFIXES = {".md", ".txt", ".json", ".yaml", ".yml"}
EXCLUDED = {".git", ".teamflow", "node_modules", ".venv", "venv", "__pycache__"}


def collect_context(design, requirements, max_chars=60000):
    path = Path(design).resolve()
    if not path.exists():
        raise TeamFlowError("design path does not exist")
    files = [path] if path.is_file() else sorted(p for p in path.rglob("*")
        if p.is_file() and p.suffix.lower() in SUFFIXES and not set(p.relative_to(path).parts)&EXCLUDED
        and not any(x.startswith(".") for x in p.relative_to(path).parts))
    if len(files) > 500:
        raise TeamFlowError("design directory has more than 500 files; select a bounded business area")
    chunks = []
    sources = []
    query = str(requirements)
    terms = set(re.findall(r"[a-zA-Z0-9_-]{2,}|[\u4e00-\u9fff]",query.lower()))
    for f in files:
        if f.is_symlink():
            raise TeamFlowError("design symlinks are not supported")
        if f.stat().st_size > 1024 * 1024:
            raise TeamFlowError(f"design file exceeds 1 MiB: {f.name}; split it first")
        text = f.read_text(encoding="utf-8")
        relative = f.name if path.is_file() else f.relative_to(path).as_posix()
        sources.append({"path":relative,"sha256":digest(text.encode())})
        lines = text.splitlines()
        for start in range(0,len(lines),60):
            body = "\n".join(lines[start:start+60])
            # Long single lines are split explicitly and retain their source line range.
            for offset in range(0,max(1,len(body)),5000):
                segment = body[offset:offset+5000]
                score = sum(t in segment.lower() for t in terms)
                chunks.append({"source":relative,"start_line":start+1,"end_line":min(start+60,len(lines)),
                               "part_offset":offset,"text":segment,"score":score})
    selected=[]
    used=0
    for c in sorted(chunks,key=lambda x:(-x["score"],x["source"],x["start_line"],x["part_offset"])):
        if used + len(c["text"]) > max_chars:
            continue
        selected.append(c); used += len(c["text"])
    if not selected:
        raise TeamFlowError("design context is empty")
    return {"sources":sources,"chunks":selected,"characters":used,"total_chunks":len(chunks),
            "selected_chunks":len(selected),"context_truncated":len(selected)<len(chunks),
            "retrieval":"keyword-ranked text chunks; semantic completeness requires review"}
