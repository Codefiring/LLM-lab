# 工单契约
## Produces
ticket-v1 的结构定义、错误码、幂等与租户规则。
## Consumes
已评审需求 R01；对应契约路径 contracts/ticket-v1/。
## Version and compatibility
ticket-v1。开发开始前应由 foundation-contracts 的真实 CI 验证并集成；此示例尚未实现契约代码。
## Mocks and verification
统一 mock 使用同一契约。验收编号 AC01；其具体测试须在试点开始前由评审者冻结。
