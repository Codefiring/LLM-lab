# LLM Router for vLLM

功能：
- OpenAI-compatible `/v1/chat/completions`
- `/v1/completions`
- `/v1/models`
- vLLM `/health` 探活
- vLLM `/metrics` 指标采集
- backend score 调度
- prefix-aware routing
- 自动失败重试
- Prometheus `/metrics`
- `/backends` 状态查看

## 启动

```bash
pip install -r requirements.txt
bash start_vllm_two_instances.sh
bash start_router.sh
```

## 测试

```bash
python test_client.py
```

## 查看状态

```bash
curl http://127.0.0.1:9000/health
curl http://127.0.0.1:9000/backends
curl http://127.0.0.1:9000/metrics
```