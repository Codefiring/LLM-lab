# git-commit-summary-html skill

This skill summarizes commits in a local Git repository during a specified time range and generates a visual self-contained HTML report.

## Files

- `SKILL.md`: skill instructions
- `commit_summary_report.py`: runnable report generator

## Basic usage

```bash
python commit_summary_report.py \
  --repo /path/to/repo \
  --since "2026-05-01" \
  --until "2026-05-31 23:59:59" \
  --output commit_summary.html
```

## Output

A standalone HTML file with feature/change groups, commit timeline details, authors, modules, and impacted files.
